// ============================================================
// SUPER JARVIS — V7-READY CORE (additive extension over SJ.execute)
// Clean extension interfaces only. NO second engine, NO parallel pipeline.
// All executable work routes through the EXISTING window.executeS6Command() -> SJ.execute().
// ============================================================
(function () {
  'use strict';
  var g = (typeof window !== 'undefined') ? window : global;
  if (g.SV7) return; // idempotent

  // Safe capability execution: ALWAYS through the existing engine. Never direct function calls.
  function runThroughEngine(id, params, source) {
    if (typeof g.executeS6Command !== 'function') {
      return Promise.resolve({ success: false, status: 'failed', error: 'Core engine unavailable' });
    }
    return g.executeS6Command(id, params || {}, source || 'v7').then(function (res) {
      return res;
    });
  }

  // ---------- CAPABILITY REGISTRY (modular, reuses ACTION_REGISTRY as tool source) ----------
  var CapabilityRegistry = {
    list: {},
    register: function (id, meta) {
      if (!id) return null;
      var tool = (g.ACTION_REGISTRY && g.ACTION_REGISTRY[id]) ? { available: true, engine: 'ACTION_REGISTRY' } : { available: false, engine: null };
      this.list[id] = {
        id: id,
        name: (meta && meta.name) || id,
        description: (meta && meta.description) || '',
        category: (meta && meta.category) || 'general',
        inputs: (meta && meta.inputs) || [],
        outputs: (meta && meta.outputs) || ['result'],
        requiredTools: tool.engine ? [id] : [],
        preferredModel: (meta && meta.preferredModel) || 'auto',
        costEstimate: (meta && meta.costEstimate) || 'unknown',
        risk: (meta && meta.risk) || 'low',
        permissions: (meta && meta.permissions) || 'none',
        dependencies: (meta && meta.dependencies) || [],
        reliability: tool.available ? 'implemented' : 'planned',
        availability: (meta && meta.availability) || (tool.available ? 'available' : 'backend_required'),
        limitations: (meta && meta.limitations) || (tool.available ? [] : ['no real tool yet — BACKEND_REQUIRED'])
      };
      return this.list[id];
    },
    registerFromRegistry: function (id) {
      var a = g.ACTION_REGISTRY && g.ACTION_REGISTRY[id];
      if (!a) return null;
      return this.register(id, { name: id, description: (a && a.description) || id, risk: a.risk || 'low', reliability: 'implemented' });
    },
    get: function (id) { return this.list[id] || null; },
    all: function () { return Object.keys(this.list).map(function (k) { return this.list[k]; }.bind(this)); }
  };
  // Seed with the existing executable actions (real tools), honest availability.
  ['task_create', 'task_complete', 'task_delete', 'task_list', 'note_create', 'note_delete', 'note_list',
   'theme_change', 'password_generate', 'pomodoro_start', 'timer_start', 'timer_stop', 'currency_convert',
   'report_generate', 'bookmark_add', 'bookmark_delete', 'calculator', 'age_calc', 'word_counter',
   'daily_quote', 'learn', 'business', 'coding', 'content', 'briefing', 'show_tasks', 'show_notes',
   'mode_change', 'random_task', 'research'].forEach(function (id) {
    if (g.ACTION_REGISTRY && g.ACTION_REGISTRY[id]) CapabilityRegistry.registerFromRegistry(id);
  });
  // Honest: backend-stub actions are NOT real external capabilities.
  CapabilityRegistry.register('research', { name: 'Web research', category: 'research', availability: 'backend_required', reliability: 'planned', limitations: ['backend/API required - not available in frontend-only'] });

  // ---------- AGENT REGISTRY (interface only; honest availability) ----------
  var AgentRegistry = {
    list: {
      research:  { id: 'research',  desc: 'Web research',       tools: ['research'],          status: 'BACKEND_REQUIRED' },
      coding:    { id: 'coding',    desc: 'Coding plan/helper', tools: ['coding'],            status: 'PLANNED' },
      content:   { id: 'content',   desc: 'Content planning',   tools: ['content'],           status: 'PLANNED' },
      business:  { id: 'business',  desc: 'Business planning',  tools: ['business'],          status: 'PLANNED' },
      finance:   { id: 'finance',   desc: 'Finance/ROI model',  tools: ['finance', 'currency_convert'], status: 'PLANNED' },
      automation:{ id: 'automation',desc: 'Automation',         tools: [],                    status: 'NOT_IMPLEMENTED' },
      data:      { id: 'data',      desc: 'Data/analytics',     tools: [],                    status: 'PLANNED' },
      system:    { id: 'system',    desc: 'System/engine',      tools: ['task_list','report_generate'], status: 'IMPLEMENTED' }
    },
    get: function (id) { return this.list[id] || null; },
    all: function () { return Object.keys(this.list).map(function (k) { return this.list[k]; }.bind(this)); }
  };

  // ---------- GOAL ENGINE ----------
  var GoalEngine = {
    goals: {},
    create: function (goal, opts) {
      var id = 'goal_' + Date.now().toString(36);
      var g = {
        id: id, goal: goal,
        outcome: (opts && opts.outcome) || goal,
        constraints: (opts && opts.constraints) || [],
        budget: (opts && opts.budget) || 'unknown',
        deadline: (opts && opts.deadline) || null,
        priority: (opts && opts.priority) || 'medium',
        riskTolerance: (opts && opts.riskTolerance) || 'low',
        status: 'planned',
        progress: 0,
        subtasks: [],
        results: [],
        createdAt: Date.now()
      };
      this.goals[g.id] = g;
      return g;
    },
    decompose: function (gid, steps) {
      var g = this.goals[gid]; if (!g) return null;
      g.subtasks = (steps || []).map(function (s) {
        return { id: 'st_' + Date.now().toString(36) + '_' + Math.floor(Math.random() * 999), title: s.title, capability: s.capability || null, agent: s.agent || 'system', status: 'pending', result: null };
      });
      g.status = 'decomposed';
      return g.subtasks;
    },
    get: function (gid) { return this.goals[gid] || null; }
  };

  // ---------- MASTER ORCHESTRATOR / HEAD AGENT (routes via SJ.execute, no 2nd engine) ----------
  var Master = {
    runGoal: function (gid) {
      var g = GoalEngine.get(gid); if (!g) return Promise.resolve({ success: false, error: 'goal not found' });
      var plan = [];
      g.subtasks.forEach(function (st) {
        if (st.capability && CapabilityRegistry.get(st.capability)) plan.push({ title: st.title, capability: st.capability, agent: st.agent });
        else plan.push({ title: st.title, capability: null, note: 'CAPABILITY_UNPLANNED' });
      });
      // Execute only capabilities that are actually available, via the existing engine.
      var chain = Promise.resolve({ success: true, results: [] });
      plan.forEach(function (step) {
        chain = chain.then(function (acc) {
          if (!step.capability) { acc.results.push({ title: step.title, status: 'UNSUPPORTED_ACTION', success: false }); return acc; }
          return runThroughEngine(step.capability, {}).then(function (r) {
            acc.results.push({ title: step.title, capability: step.capability, status: r.status || 'failed', success: !!(r && r.success) });
            return acc;
          });
        });
      });
      return chain.then(function (acc) {
        var ok = acc.results.filter(function (r) { return r.success; }).length;
        g.status = acc.results.every(function (r) { return r.success; }) ? 'completed' : 'partial';
        g.progress = Math.round((ok / Math.max(acc.results.length, 1)) * 100);
        g.results = acc.results;
        return { goal: g, results: acc.results, progress: g.progress, status: g.status };
      });
    }
  };

  // ---------- TOOL INTERFACE (structured capability metadata + permission/risk, no arbitrary exec) ----------
  var ToolInterface = {
    describe: function (capId) {
      var c = CapabilityRegistry.get(capId);
      if (!c) return { id: capId, status: 'UNSUPPORTED_ACTION', available: false };
      return c;
    },
    run: function (capId, params) {
      return runThroughEngine(capId, params || {}); // -> window.executeS6Command -> SJ.execute (single engine)
    }
  };

  // ---------- MODEL ROUTER FOUNDATION (abstraction only; no hard-coded single model) ----------
  var ModelRouter = {
    modelPool: [],
    addModel: function (m) { if (m && m.id) this.modelPool.push(m); return m; },
    choose: function (task) {
      // Simple foundation scoring; extendable without touching Core Engine.
      var pool = this.modelPool.length ? this.modelPool : [{ id: 'local-heuristic', accuracy: 0.6, reasoning: 'low', speed: 'fast', cost: 0, privacy: 'high' }];
      return pool.slice().sort(function (a, b) { return (b.accuracy || 0) - (a.accuracy || 0); })[0] || pool[0];
    },
    addCoreModels: function () {
      // Registered locally; providers added later without rewriting Core Engine.
      this.addModel({ id: 'local-heuristic', accuracy: 0.6, reasoning: 'low', speed: 'fast', cost: 0, privacy: 'high', multimodal: false });
      this.addModel({ id: 'backend-model', accuracy: 0.8, reasoning: 'high', speed: 'medium', cost: 'unknown', privacy: 'medium', multimodal: true, availability: 'BACKEND_REQUIRED' });
    }
  };
  ModelRouter.addCoreModels();

  // ---------- DECISION / ROI LAYER ----------
  var DecisionLayer = {
    evaluate: function (options) {
      // expected value, cost, time, complexity, risk, success probability
      var scored = options.map(function (o) {
        var ev = (o.value || 0) * (o.successProb || 0.5);
        var roi = (o.cost > 0) ? (ev - o.cost) : ev;
        return {
          option: o.option,
          expectedValue: Math.round(ev * 100) / 100,
          cost: o.cost || 0,
          risk: o.risk || 'medium',
          roi: Math.round(roi * 100) / 100,
          why: o.why || ''
        };
      });
      scored.sort(function (a, b) { return b.roi - a.roi; });
      var best = scored[0] || null;
      return {
        best: best,
        why: best ? best.why : '',
        alternatives: scored.slice(1),
        risks: options.filter(function (o) { return o.risk === 'high'; }).map(function (o) { return o.option; }),
        expectedROI: best ? best.score : 0,
        nextStep: best ? ('Execute ' + best.option) : 'none'
      };
    }
  };

  // ---------- SELF-AUDIT FOUNDATION (safe; critical changes need approval) ----------
  var SelfAudit = {
    plan: function (issue) {
      return { detect: issue, diagnose: null, rootCause: null, safeFix: null, test: null, retry: null, approval: 'REQUIRED' };
    },
    propose: function (audit, rootCause, fix) {
      audit.diagnose = true; audit.rootCause = rootCause; audit.proposeFix = fix;
      return audit; // human approval still required before apply
    },
    needsApproval: function (audit) { return !!(audit && audit.proposeFix); }
  };

  // ---------- SKILL FACTORY (sandbox -> test -> validate -> approval -> production) ----------
  var SkillFactory = {
    skills: {},
    create: function (name, def) {
      return { name: name, def: def || {}, lifecycle: 'SANDBOX' };
    },
    test: function (s) { if (s.lifecycle === 'SANDBOX') s.lifecycle = 'TEST'; return s; },
    validate: function (s) { if (s.lifecycle === 'TEST') s.lifecycle = 'VALIDATED'; return s; },
    approve: function (s) { if (s.lifecycle === 'VALIDATED') s.lifecycle = 'PRODUCTION'; return s; }
    // No skill is ever auto-trusted; approval is an explicit human step.
  };

  // ---------- MEMORY EXTENSION (reuses existing SJMemory, adds typed views) ----------
  var MemoryExt = {
    base: function () { return (g.SJMemory) || null; },
    _stripSecrets: function (text) {
      return String(text || '').replace(/(pass\w*|token|api[_ ]?key|secret|credential)[=:]\s*\S+/gi, '$1=[REDACTED]');
    },
    remember: function (type, content, source, importance) {
      var b = this.base(); if (!b || typeof b.add !== 'function') return Promise.resolve({ ok: false, error: 'memory base unavailable' });
      return b.add(type, this._stripSecrets(content), source || 'v7', importance || 0.3);
    }
  };

  // Public surface — extension points ONLY. Does NOT override or replace SJ.execute().
  g.SV7 = {
    version: '0.1.0',
    engine: 'SJ.execute()', // the single authoritative engine; this module extends it, never replaces it
    CapabilityRegistry: CapabilityRegistry,
    AgentRegistry: AgentRegistry,
    GoalEngine: GoalEngine,
    MasterOrchestrator: Master,
    ToolInterface: ToolInterface,
    ModelRouter: ModelRouter,
    DecisionLayer: DecisionLayer,
    SelfAudit: SelfAudit,
    SkillFactory: SkillFactory,
    Memory: MemoryExt
  };
})();