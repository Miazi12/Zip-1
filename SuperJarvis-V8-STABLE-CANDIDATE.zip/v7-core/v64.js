// ============ SUPER JARVIS V6.4 — RELIABLE PERMISSION-BASED AGENT PIPELINE ============
// Additive upgrade over V6.2/V6.3. Replaces the global confirmation system with a
// command-specific one, centralizes risk, adds missing safe actions, improves param
// extraction (colon syntax), enriches history/memory/state, and upgrades the QA suite.
// NO fake success. Backend-required capabilities are honestly marked BACKEND REQUIRED.
(function(){
"use strict";
if(typeof window==='undefined'||typeof window.executeS6Command!=='function')return;
if(window.__sjv64)return; window.__sjv64=1;

var $=function(id){return document.getElementById(id)};
function V6esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])})}
function readJSON(k,fb){try{var v=JSON.parse(localStorage.getItem(k));return v==null?fb:v}catch(e){return fb}}
function writeJSON(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}

// ---------- 3. CENTRAL RISK SOURCE (single authority) ----------
var RISK_CATEGORY={
  MEDIUM:['research','report_generate','currency_convert','export_data','open_link','weather','news','finance','content','summarize'],
  HIGH:['delete_task','delete_note','delete_bookmark','task_delete','note_delete','bookmark_delete','file_modify','account_action','external_send','clear_all','reset_all'],
  CRITICAL:['financial_transaction','trading','credential_op','destructive_op','delete_all']
};
function riskOf(action){
  var reg=(window.ACTION_REGISTRY||{});
  var a=reg[action];
  if(a&&a.risk)return a.risk; // registry is the source of truth
  if(RISK_CATEGORY.CRITICAL.indexOf(action)>-1)return 'CRITICAL';
  if(RISK_CATEGORY.HIGH.indexOf(action)>-1)return 'HIGH';
  if(RISK_CATEGORY.MEDIUM.indexOf(action)>-1)return 'MEDIUM';
  return 'LOW';
}
function isDestructive(action){ return /delete|remove|clear|reset|wipe|erase|trash/i.test(String(action||'')); }
function needsConfirm(rec){
  var r=(rec&&rec.risk)||riskOf(rec&&rec.intent);
  if(r==='HIGH'||r==='CRITICAL')return true;
  if(r==='MEDIUM'){ var a=(window.ACTION_REGISTRY||{})[rec&&rec.intent]; return isDestructive(rec&&rec.intent)||(a&&a.reversible===false); }
  return false; // LOW executes directly
}
// Patch the public Permissions object so riskFor agrees with the registry (one source).
if(window.SJPermissions){ try{
  window.SJPermissions.riskFor=function(action){return riskOf(action)};
  window.SJPermissions.needsConfirm=function(risk){return risk==='HIGH'||risk==='CRITICAL'};
  window.SJPermissions.check=function(rec){
    var risk=riskOf(rec&&rec.intent);
    var required=needsConfirm({intent:rec&&rec.intent,risk:risk});
    var confirmed=window.S6&&window.S6.isConfirmed?window.S6.isConfirmed(rec&&rec.id):false;
    return Promise.resolve({allowed:!required||confirmed,required:required,risk:risk});
  };
}catch(e){} }

// Enrich + normalize every registered action (additive, no overrides of logic)
function enrichRegistry(){
  var reg=window.ACTION_REGISTRY; if(!reg)return;
  for(var k in reg){ var a=reg[k]; if(!a)continue;
    if(!a.id)a.id=k;
    if(!a.description)a.description=String(k).replace(/_/g,' ');
    a.risk=riskOf(k);                          // force single-source risk
    if(typeof a.reversible!=='boolean')a.reversible=!isDestructive(k);
    if(typeof a.requiresPermission!=='boolean')a.requiresPermission=needsConfirm({intent:k,risk:a.risk});
  }
}
// Param-compat: many V6.2 actions read a string `p` but chat/voice/mode send {text}
function wrapParamActions(){
  var reg=window.ACTION_REGISTRY; if(!reg)return;
  function txt(p){return ((p&&p.text)!=null)?p.text:((p&&p.name)!=null)?p.name:p}
  ['task_delete','note_delete','bookmark_delete'].forEach(function(an){var a=reg[an];if(a&&a.execute){var e=a.execute,v=a.verify;a.execute=function(p){return e(txt(p))};if(v)a.verify=function(p){return v(txt(p))};}});
  if(reg.theme_change){var t=reg.theme_change.execute;reg.theme_change.execute=function(p){var nm=((p&&p.theme)!=null)?p.theme:((p&&p.name)!=null)?p.name:p;return t(String(nm))};}
  if(reg.task_complete){var c=reg.task_complete.execute,cv=reg.task_complete.verify;reg.task_complete.execute=function(p){return c(txt(p))};if(cv)reg.task_complete.verify=function(p){return cv(txt(p))};}
}

// ---------- SAFE CALCULATOR (no eval / no Function) ----------
function safeCalc(expr){
  var src=String(expr==null?'':expr).replace(/[^0-9+\-*/().%\s]/g,'').trim(); if(!src)return null;
  var i=0; function pk(){return src[i]||''}
  function num(){var st=i; while(i<src.length&&/[0-9.]/.test(src[i]))i++; var v=parseFloat(src.slice(st,i)); if(isNaN(v))throw 0; return v}
  function prim(){var c=pk(); if(c==='('){i++;var v=add(); if(pk()===')')i++; return v} if(c==='-'){i++;return -prim()} return num()}
  function mul(){var v=prim(); for(;;){var c=pk(); if(c==='*'){i++;v*=prim()}else if(c==='/'){i++;var d=prim();if(d===0)throw 0;v/=d}else if(c==='%'){i++;var m=prim();if(m===0)throw 0;v%=m}else break} return v}
  function add(){var v=mul(); for(;;){var c=pk(); if(c==='+'){i++;v+=mul()}else if(c==='-'){i++;v-=mul()}else break} return v}
  try{var r=add(); return isFinite(r)?Math.round(r*1e6)/1e6:null}catch(e){return null}
}

// ---------- 4. ADD MISSING SAFE ACTIONS (additive, only if not present) ----------
function registerIfMissing(id,def){var reg=window.ACTION_REGISTRY;if(!reg)return;if(!reg[id]){def.id=id;reg[id]=def;}}
(function(){
  registerIfMissing('calculator',{description:'Safe arithmetic calculator',risk:'LOW',reversible:true,requiresPermission:false,
    execute:function(p){var e=String((p&&p.expr)!=null?(p&&p.expr):(p&&p.text)||'').trim();if(!e)return{ok:false,error:'No expression'};var v=safeCalc(e);return v===null?{ok:false,error:'Invalid expression'}:{ok:true,result:v}},
    verify:function(p){var e=String((p&&p.expr)!=null?(p&&p.expr):(p&&p.text)||'').trim();return safeCalc(e)!==null}});
  registerIfMissing('age_calc',{description:'Calculate age from birth date',risk:'LOW',reversible:true,requiresPermission:false,
    execute:function(p){var b=String((p&&p.birth)!=null?(p&&p.birth):(p&&p.text)||'').trim();if(!b)return{ok:false,error:'Birth date required (params.birth)'};var bd=new Date(b);if(isNaN(bd))return{ok:false,error:'Invalid date'};var d=new Date();var age=d.getFullYear()-bd.getFullYear();var m=d.getMonth()-bd.getMonth();if(m<0||(m===0&&d.getDate()<bd.getDate()))age--;return{ok:true,result:Math.max(0,age)}},
    verify:function(p){var b=String((p&&p.birth)!=null?(p&&p.birth):(p&&p.text)||'').trim();return !!b&&!isNaN(new Date(b))}});
  registerIfMissing('word_counter',{description:'Count words and characters',risk:'LOW',reversible:true,requiresPermission:false,
    execute:function(p){var t=String((p&&p.text)||'').trim();if(!t)return{ok:false,error:'No text'};var w=t.split(/\s+/).filter(Boolean).length;return{ok:true,result:{words:w,chars:t.length}}},
    verify:function(p){return String((p&&p.text)||'').trim().length>0}});
  registerIfMissing('daily_quote',{description:'Daily motivational quote',risk:'LOW',reversible:true,requiresPermission:false,
    execute:function(){var q=(typeof quotes!=='undefined'&&quotes.length)?quotes[Math.floor(Math.random()*quotes.length)]:['Small steps make big results.','Super Jarvis'];return{ok:true,result:q[0]+' — '+q[1]}},
    verify:window.verByOutput});
  registerIfMissing('task_list',{description:'List all tasks',risk:'LOW',reversible:true,requiresPermission:false,
    execute:function(){var t=(typeof tlist!=='undefined')?tlist:readJSON('sj_tasks',[]);var s=t.length?t.map(function(x,i){return(x.done?'✅':'⬜')+' '+x.text}).join('\n'):'No tasks';return{ok:true,result:s}},
    verify:window.verByOutput});
  registerIfMissing('note_list',{description:'List all notes',risk:'LOW',reversible:true,requiresPermission:false,
    execute:function(){var n=(typeof notes!=='undefined')?notes:readJSON('sj_notes',[]);var s=n.length?n.join('\n'):'No notes';return{ok:true,result:s}},
    verify:window.verByOutput});
  registerIfMissing('timer_stop',{description:'Stop focus timer',risk:'LOW',reversible:true,requiresPermission:false,
    execute:function(){if($('fReset'))$('fReset').click();return{ok:true}},
    verify:function(){return typeof fRunning==='undefined'||fRunning===false}});
})();

// ---------- 2. COMMAND-SPECIFIC CONFIRMATION (one confirmation never authorizes another) ----------
var _confirmTokens={};
function confirmPermission(rec){
  var auto=window.S6&&window.S6.autoConfirm;
  if(auto==='deny')return Promise.resolve(false);
  if(auto==='allow'&&window.__S6_TEST__)return Promise.resolve(true);
  return new Promise(function(res){try{
    if(typeof askPermission==='function'){askPermission('Allow '+rec.intent+' (risk '+rec.risk+')?',function(){res(true)})}
    else{res(window.confirm&&confirm('Allow '+rec.intent+' (risk '+rec.risk+')?'))}
  }catch(e){res(false)}});
}

// ---------- 9. HISTORY (max 100, localStorage) ----------
var HISTKEY='sj_engine_history_v1';
var _histFilter='all';
function addHistory(rec){
  var h=readJSON(HISTKEY,[]);
  h.unshift({commandId:rec.commandId,intent:rec.intent,params:redactParams(rec.params),source:rec.source,risk:rec.risk,status:rec.status,timestamp:new Date().toISOString(),executionTime:rec.executionTime,verified:rec.verified,error:rec.error||null});
  if(h.length>100)h.length=100; writeJSON(HISTKEY,h);
  renderHistoryV64(_histFilter);
}
function redactParams(p){var o={};try{for(var k in p){if(/pass|secret|token|pwd|credential/i.test(k))o[k]='[REDACTED]';else o[k]=p[k];}return o}catch(e){return{}}}
function renderHistoryV64(filter){
  var box=$('engHist'); if(!box)return;
  var h=readJSON(HISTKEY,[]); var list=h;
  if(filter==='completed')list=h.filter(function(x){return x.status==='completed'});
  else if(filter==='failed')list=h.filter(function(x){return x.status==='failed'||x.status==='permission_denied'||x.error});
  else if(filter==='permission')list=h.filter(function(x){return x.status==='permission_required'||x.status==='permission_denied'});
  if(!list.length){box.innerHTML='<div class="act">No history</div>';return}
  box.innerHTML=list.slice(0,20).map(function(r){
    var ico=r.status==='completed'?'✅':r.status==='failed'?'❌':(r.status==='permission_denied'||r.status==='permission_required')?'🔐':'⏳';
    var line='['+r.risk+'] '+V6esc(r.intent||'')+' · '+V6esc(r.status||'')+(r.error?(' · '+V6esc(r.error)):'');
    return '<div class="act" title="'+V6esc(r.commandId||'')+'"><span class="aic">'+ico+'</span><span class="atx">'+line+'</span><span class="ats">'+(r.executionTime?r.executionTime+'ms':'')+'</span></div>';
  }).join('');
}

// ---------- PANEL / STATUS UI ----------
function updatePanel(rec){
  function set(id,v){try{var e=$(id);if(e)e.textContent=v}catch(e){}}
  set('engStage','Stage: '+(rec.status||'idle'));
  set('engCmd','Command: '+(rec.intent||'—'));
  set('engRisk','Risk: '+(rec.risk||'—'));
  set('engPerm','Permission: '+(rec.permissionRequired?('required ('+rec.risk+')'):('auto ('+rec.risk+')')));
  set('engVerify','Verification: '+(rec.status==='verified'||rec.status==='completed'?'passed':rec.status==='verifying'?'checking':rec.status==='failed'?'failed':'pending'));
  set('engTime','Exec time: '+((rec.executionTime||0))+'ms');
  set('engResult','Last Result: '+shortText(rec.result,40));
  var on=$('engOnline'); if(on){on.textContent=rec.status==='failed'?'🔴 CORE ENGINE ERROR':rec.status==='permission_denied'?'🟡 PERMISSION DENIED':'🟢 CORE ENGINE ONLINE';on.style.color=rec.status==='failed'?'#ff6b6b':(rec.status==='permission_denied'?'#ffd24d':'#8affc1');}
}
function shortText(v,n){var s=String(v==null?'':v).replace(/\s+/g,' ').trim();return s.length>(n||40)?s.slice(0,n||40)+'…':s}
function isSecretIntent(i){return /pass|secret|token|credential|pwd/i.test(String(i||''))}

// ---------- 1. COMMAND PIPELINE (reliable, command-specific confirmation) ----------
function execute6Command(intent,params,source){
  params=params||{}; source=source||'ui';
  var cmdId='cmd_'+Date.now().toString(36)+'_'+Math.floor(Math.random()*1e6).toString(36);
  var reg=(window.ACTION_REGISTRY||{});
  var action=reg[intent];
  if(!action){
    return Promise.resolve({success:false,commandId:cmdId,intent:String(intent||''),result:null,verified:false,status:'failed',error:'Unknown action: '+intent+' (not registered)',risk:'LOW',source:source,executionTime:0});
  }
  var rec={commandId:cmdId,intent:String(intent||''),params:params,source:source,risk:riskOf(intent),permissionRequired:false};
  rec.permissionRequired=needsConfirm(rec);
  var t0=Date.now();
  function toOut(res){
    var out={success:(res&&res.success===true),commandId:cmdId,intent:rec.intent,result:(res&&res.result)||null,verified:!!(res&&res.verified),status:(res&&res.status)||'failed',error:(res&&res.error)||null,risk:rec.risk,source:rec.source,executionTime:Date.now()-t0};
    try{addHistory(out);updatePanel(out);}catch(e){}
    try{var st=window.SJState;if(st){st.set('lastCommand',rec.intent);st.set('engineStatus','online');st.set('lastResult',out.result);st.set('lastError',out.error||null);}}catch(e){}
    return out;
  }
  function go(){
    if(!window.SJ||typeof window.SJ.execute!=='function'){return Promise.resolve({success:false,commandId:cmdId,intent:rec.intent,result:null,verified:false,status:'failed',error:'Core engine (SJ) unavailable',risk:rec.risk,source:rec.source,executionTime:0});}
    return window.SJ.execute({id:cmdId,intent:rec.intent,params:rec.params,source:rec.source}).then(toOut);
  }
  if(rec.permissionRequired){
    return confirmPermission(rec).then(function(ok){
      if(!ok){return Promise.resolve({success:false,commandId:cmdId,intent:rec.intent,result:null,verified:false,status:'permission_denied',error:'Permission not granted — command NOT authorized',risk:rec.risk,source:rec.source,executionTime:0});}
      _confirmTokens[cmdId]=true;
      return go();
    });
  }
  return go();
}
// PUBLIC BRIDGE (single definition — replaces the old global)
window.executeS6Command=execute6Command;
// Expose the upgraded QA suite under the existing global name (not broken)
window.runEngineTests=runEngineTests;

// ---------- EXPOSE S6 NAMESPACE (also used by QA tests) ----------
window.S6={version:'6.4.0',autoConfirm:null,riskOf:riskOf,isConfirmed:function(id){return !!_confirmTokens[id]},execute:execute6Command,history:function(){return readJSON(HISTKEY,[])},runTests:runEngineTests,calc:safeCalc};

// ---------- 13. QA SUITE (20+ real tests, verify actual state) ----------
function runEngineTests(){
  var box=$('engTests'); if(!box)return;
  box.innerHTML='';
  var defs=[];
  function T(name,fn){defs.push({name:name,fn:fn})}
  function line(name,ok){var d=document.createElement('div');d.className='act '+(ok?'ok':'fail');d.innerHTML='<span class="aic">'+(ok?'✅':'❌')+'</span><span class="atx">'+V6esc(name)+'</span><span class="ats">'+(ok?'PASS':'FAIL')+'</span>';box.appendChild(d)}
  async function run(){
    var t0=Date.now(), qs=Date.now().toString(36);
    var tarr=function(){return(typeof tlist!=='undefined')?tlist:readJSON('sj_tasks',[])};
    var narr=function(){return(typeof notes!=='undefined')?notes:readJSON('sj_notes',[])};
    var tk='QA_TASK_'+qs, nt='QA_NOTE_'+qs;
    function deny(){window.__S6_TEST__=true;window.S6.autoConfirm='deny'}
    function resetA(){window.S6.autoConfirm=null;delete window.__S6_TEST__}
    T('01 task create',async function(){var r=await execute6Command('task_create',{text:tk});return r&&r.success===true&&tarr().some(function(x){return x.text===tk})});
    T('02 task list',async function(){var r=await execute6Command('task_list',{});return r&&r.success===true&&String(r.result||'').length>0});
    T('03 task complete',async function(){var k=tk+'_c';await execute6Command('task_create',{text:k});var r=await execute6Command('task_complete',{text:k});return r&&r.success===true&&tarr().some(function(x){return x.text===k&&x.done})});
    T('04 task delete REQUIRES confirm',async function(){deny();var r=await execute6Command('task_delete',{text:tk});resetA();return r&&r.status==='permission_denied'});
    T('05 note create',async function(){var r=await execute6Command('note_create',{text:nt});return r&&r.success===true&&narr().indexOf(nt)>-1});
    T('06 note list',async function(){var r=await execute6Command('note_list',{});return r&&r.success===true&&String(r.result||'').length>0});
    T('07 note delete REQUIRES confirm',async function(){deny();var r=await execute6Command('note_delete',{text:nt});resetA();return r&&r.status==='permission_denied'});
    T('08 theme change (gold)',async function(){var r=await execute6Command('theme_change',{theme:'gold'});return r&&r.success===true&&r.result&&String(r.result).length>0});
    T('09 password generate (min 8)',async function(){var r=await execute6Command('password_generate',{});return r&&r.success===true&&String(r.result||'').length>=8});
    T('10 pomodoro start',async function(){var r=await execute6Command('pomodoro_start',{});return r&&r.success===true});
    T('11 focus timer',async function(){var r=await execute6Command('timer_start',{});return r&&r.success===true});
    T('12 currency convert',async function(){var r=await execute6Command('currency_convert',{amount:100,from:'USD',to:'BDT'});return r&&r.success===true&&typeof r.result==='number'});
    T('13 report generate',async function(){var r=await execute6Command('report_generate',{text:'QA report'});return r&&r.success===true&&String(r.result||'').length>0});
    T('14 bookmark add',async function(){var r=await execute6Command('bookmark_add',{url:'https://example.com/qa'});return r&&r.success===true});
    T('15 bookmark delete REQUIRES confirm',async function(){deny();var r=await execute6Command('bookmark_delete',{text:'https://example.com/qa'});resetA();return r&&r.status==='permission_denied'});
    T('16 unknown command rejected',async function(){var r=await execute6Command('frobnicate_xyz',{});return r&&r.status==='failed'&&/unknown/i.test(r.error||'')});
    T('17 research BACKEND REQUIRED (honest fail)',async function(){var r=await execute6Command('research',{});return r&&r.success===false&&r.status==='failed'});
    T('18 chat -> engine',async function(){var r=await execute6Command('task_create',{text:'QA_CHAT_'+qs},'chat');return r&&r.source==='chat'&&r.success===true});
    T('19 voice -> engine',async function(){var r=await execute6Command('theme_change',{theme:'green'},'voice');return r&&r.source==='voice'&&r.success===true});
    T('20 permission isolation (A≠B)',async function(){window.__S6_TEST__=true;window.S6.autoConfirm='allow';var a=await execute6Command('bookmark_delete',{text:'https://example.com/iso'});window.S6.autoConfirm='deny';var b=await execute6Command('note_delete',{text:nt});resetA();return (a&&a.success===true)&&(b&&b.status==='permission_denied')});
    T('21 briefing',async function(){var r=await execute6Command('briefing',{});return r&&r.success===true});
    T('22 calculator (no eval)',async function(){var r=await execute6Command('calculator',{expr:'(2+3)*4'});return r&&r.success===true&&r.result===20});
    var pass=0;
    for(var i=0;i<defs.length;i++){var o=defs[i],ok=false;try{ok=await o.fn()}catch(e){ok=false}if(ok)pass++;line(o.name,ok)}
    var tot=document.createElement('div');tot.className='act';tot.innerHTML='<span class="ats">'+pass+'/'+defs.length+' PASS · '+((Date.now()-t0)/1000).toFixed(1)+'s</span>';box.appendChild(tot);
  }
  run();
}

// ---------- PANEL INIT (add rows + rebind history/tests, once) ----------
function initPanel(){
  var sec=$('sjEnginePanels'); if(!sec)return;
  var grid=sec.querySelector('.cc-grid');
  if(grid){
    if(!$('engPerm')){var d=document.createElement('div');d.className='st';d.id='engPerm';d.textContent='Permission: —';grid.appendChild(d)}
    if(!$('engResult')){var d2=document.createElement('div');d2.className='st';d2.id='engResult';d2.textContent='Last Result: —';grid.appendChild(d2)}
  }
  var h2=sec.querySelector('h2'); if(h2)h2.textContent='⚙️ CORE ENGINE · V6.4';
  var hf=sec.querySelector('#hFilt'); if(hf)hf.querySelectorAll('button').forEach(function(b){b.onclick=function(){_histFilter=b.getAttribute('data-f')||'all';renderHistoryV64(_histFilter)}});
  var rb=$('engRunTests'); if(rb){rb.textContent='▶ Run 22 Engine Tests';rb.onclick=runEngineTests}
  renderHistoryV64(_histFilter);
}
enrichRegistry();
wrapParamActions();
if(window.SJ){try{window.SJ.version='6.4.0'}catch(e){}}
function _boot(){initPanel();}
if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',_boot)}else{setTimeout(_boot,150)}
})();
