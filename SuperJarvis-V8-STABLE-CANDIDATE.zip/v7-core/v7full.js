// ============================================================
// SUPER JARVIS — V7 EXTENSION (full V7 core on top of SJ.execute)
// Additive. NO second engine. All executable work -> window.executeS6Command -> SJ.execute().
// Extends window.SV7 (set up by v7core.js). Idempotent.
// ============================================================
(function () {
  'use strict';
  var g = (typeof window !== 'undefined') ? window : global;
  if (!g.SV7 || g.SV7._full) return;
  var base = g.SV7;

  function runThroughEngine(id, params, source) {
    if (typeof g.executeS6Command !== 'function') {
      return Promise.resolve({ success: false, status: 'failed', error: 'Core engine unavailable' });
    }
    return g.executeS6Command(id, params || {}, source || 'v7');
  }
  function riskOf(id) {
    var a = (g.ACTION_REGISTRY && g.ACTION_REGISTRY[id]) || {};
    var r = String((a.risk) || 'low').toUpperCase();
    return r;
  }

  // ---------- TOOL REGISTRY (standardized metadata + controlled execution) ----------
  var ToolRegistry = {
    tools: {},
    register: function (capability, meta) {
      var cap = base.CapabilityRegistry.get(capability);
      if (!cap) return null;
      var tool = {
        id: capability,
        name: (meta && meta.name) || capability,
        description: (meta && meta.description) || cap.description || '',
        category: (meta && meta.category) || cap.category || 'general',
        inputs: cap.inputs || [],
        outputs: cap.outputs || ['result'],
        risk: (meta && meta.risk) || cap.risk || 'low',
        permissions: (meta && meta.permissions) || cap.permissions || 'none',
        model: (meta && meta.model) || cap.preferredModel || 'auto',
        backendRequired: !!cap.backendRequired || cap.availability === 'backend_required',
        available: cap.availability === 'available',
        verify: (meta && meta.verify) || 'current_engine_verifier', // uses SJ engine verifier
        execute: function (params) { return runThroughEngine(capability, params || {}); } // -> SJ.execute
      };
      this.tools[capability] = tool;
      return tool;
    },
    get: function (id2) { return this.tools[id2] || null; },
    all: function () { return Object.keys(this.tools).map(function (k) { return this.tools[k]; }.bind(this)); }
  };

  // ---------- SKILL REGISTRY (guarded lifecycle, no auto-trust) ----------
  var SKILL_STAGES = ['DISCOVER', 'DESIGN', 'SANDBOX', 'TEST', 'VALIDATE', 'APPROVAL', 'PRODUCTION'];
  var SkillRegistry = {
    skills: {},
    create: function (name, def) {
      var s = { name: name, def: def || {}, stage: 'DISCOVER', history: ['DISCOVER'], createdAt: Date.now() };
      this.skills[name] = s; return s;
    },
    _advance: function (s, to) {
      var cur = s.stage, i = SKILL_STAGES.indexOf(cur), j = SKILL_STAGES.indexOf(to);
      if (i < 0 || j < 0 || j < i || j > i + 1) { return { ok: false, error: 'invalid transition ' + cur + ' -> ' + to }; }
      s.stage = to; s.history.push(to); return { ok: true, stage: s.stage };
    },
    discover: function (s) { return this._advance(s, 'DISCOVER'); },
    design: function (s) { return this._advance(s, 'DESIGN'); },
    sandbox: function (s) { return this._advance(s, 'SANDBOX'); },
    test: function (s) { return this._advance(s, 'TEST'); },
    validate: function (s) { return this._advance(s, 'VALIDATE'); },
    approve: function (s) { return this._advance(s, 'APPROVAL'); },
    release: function (s) { return this._advance(s, 'PRODUCTION'); }, // explicit human approval required to reach here
    get: function (name) { return this.skills[name] || null; }
  };

  // ---------- TASK GRAPH / WORKFLOW ENGINE (uses SJ.execute; no second engine) ----------
  var TaskGraph = {
    graphs: {},
    new: function (name) { var g = { id: 'graph_' + Date.now().toString(36), name: name || 'workflow', tasks: {}, order: [] }; this.graphs[g.id] = g; return g; },
    add: function (g, task) {
      if (!g || !task || !task.id) return null;
      g.tasks[task.id] = {
        id: task.id,
        title: task.title || task.id,
        capability: task.capability || null,
        params: task.params || {},
        dependsOn: task.dependsOn || [],
        risk: String(task.risk || 'low').toUpperCase(),
        retryLimit: task.retryLimit != null ? task.retryLimit : 0,
        verify: task.verify !== false,
        status: 'pending', result: null, error: null, attempts: 0
      };
      g.order.push(task.id);
      return g.tasks[task.id];
    },
    _ready: function (g, id) {
      var t = g.tasks[id]; if (!t || t.status !== 'pending') return false;
      for (var i = 0; i < t.dependsOn.length; i++) { var d = g.tasks[t.dependsOn[i]]; if (!d || d.status !== 'completed') return false; }
      return true;
    },
    run: function (g, opts) {
      opts = opts || {};
      var self = this;
      return new Promise(function (resolve) {
        // promotion: approval_required tasks become pending again once their approval token arrives
        Object.keys(g.tasks).forEach(function (id) {
          var tt = g.tasks[id];
          if (tt.status === 'approval_required' && opts.approvals && opts.approvals[id]) tt.status = 'pending';
        });
        var pending = Object.keys(g.tasks).filter(function (id) { return g.tasks[id].status === 'pending'; });
        if (!pending.length) { return resolve({ status: g._cancelled ? 'cancelled' : 'completed', graph: g.id, tasks: g.tasks }); }
        var batch = pending.filter(function (id) { return self._ready(g, id); });
        if (!batch.length) {
          // dependency deadlock
          g.tasks[pending[0]].status = 'failed'; g.tasks[pending[0]].error = 'dependency unsatisfied';
          return resolve({ status: 'failed', graph: g.id, tasks: g.tasks });
        }
        var jobs = batch.map(function (id) { return self._execOne(g, id, opts); });
        Promise.all(jobs).then(function () {
          self.run(g, opts).then(resolve); // recurse to pick up newly-ready tasks (bounded, no new engine)
        });
      });
    },
    _execOne: function (g, id, opts) {
      var t = g.tasks[id];
      t.status = 'running';
      var risk = t.risk;
      // approval gate: HIGH/CRITICAL need an explicit approval token for this exact command
      var needApproval = (risk === 'HIGH' || risk === 'CRITICAL');
      if (needApproval && !(opts.approvals && opts.approvals[id])) {
        t.status = 'approval_required'; return Promise.resolve();
      }
      if (!t.capability) { t.status = 'unsupported'; t.error = 'UNSUPPORTED_ACTION'; return Promise.resolve(); }
      var attempt = function (left) {
        if (left <= 0) { t.status = 'failed'; return; }
        return runThroughEngine(t.capability, t.params).then(function (r) {
          t.attempts++;
          var ok = !!(r && r.success === true);
          if (t.verify) { ok = ok && r.status === 'completed'; } // verification gate: completed only after verified
          if (ok) { t.status = 'completed'; t.result = r.result != null ? r.result : r; }
          else { if (left - 1 > 0) return attempt(left - 1); t.status = 'failed'; t.error = (r && r.error) || 'execution or verification failed'; }
        });
      };
      return attempt(t.retryLimit + 1);
    },
    cancel: function (g) { g._cancelled = true; Object.keys(g.tasks).forEach(function (id) { if (g.tasks[id].status === 'pending') g.tasks[id].status = 'cancelled'; }); return g; },
    statusOf: function (g) {
      var ids = Object.keys(g.tasks); if (!ids.length) return 'empty';
      if (ids.some(function (i) { return g.tasks[i].status === 'failed'; })) return 'failed';
      if (ids.some(function (i) { return g.tasks[i].status === 'approval_required'; })) return 'approval_required';
      if (ids.every(function (i) { return g.tasks[i].status === 'completed'; })) return 'completed';
      return 'running';
    }
  };

  // ---------- MASTER ORCHESTRATOR (goal -> understand -> graph -> select -> plan -> permission -> execute -> verify -> report) ----------
  var MasterOrchestrator = {
    planGoal: function (goalText, subtasks) {
      var goal = base.GoalEngine.create(goalText, { outcome: goalText });
      base.GoalEngine.decompose(goal.id, (subtasks || []).map(function (s) {
        return { title: s.title, capability: s.capability, agent: s.agent || 'system' };
      }));
      var graph = TaskGraph.new('goal_' + goal.id);
      (subtasks || []).forEach(function (s, i) {
        TaskGraph.add(graph, { id: 't' + (i + 1), title: s.title, capability: s.capability, params: s.params || {}, risk: s.risk || 'low', dependsOn: s.dependsOn || [] });
      });
      return { goal: goal, graph: graph };
    },
    runGoal: function (goalText, subtasks, opts) {
      var p = this.planGoal(goalText, subtasks);
      return TaskGraph.run(p.graph, opts).then(function (res) {
        var goal = p.goal;
        var done = Object.keys(p.graph.tasks).filter(function (i) { return p.graph.tasks[i].status === 'completed'; }).length;
        var total = Object.keys(p.graph.tasks).length;
        goal.progress = Math.round((done / Math.max(total, 1)) * 100);
        goal.status = p.graph._cancelled ? 'cancelled' : (TaskGraph.statusOf(p.graph));
        goal.results = Object.keys(p.graph.tasks).map(function (i) { return { id: p.graph.tasks[i].id, status: p.graph.tasks[i].status, title: p.graph.tasks[i].title }; });
        return { goal: goal, graph: p.graph, status: goal.status, progress: goal.progress };
      });
    }
  };

  // ---------- SAFE AUTONOMY (policy tiers; HIGH/CRITICAL never auto) ----------
  var Autonomy = {
    policy: { LOW: 'auto', MEDIUM: 'auto', HIGH: 'approval', CRITICAL: 'approval' },
    canAutoRun: function (risk) { return this.policy[String(risk).toUpperCase()] === 'auto'; },
    classify: function (capability) { return riskOf(capability); },
    gate: function (capability, approvals) { // returns {allowed, reason}
      var r = this.classify(capability);
      if (this.canAutoRun(r)) return { allowed: true, reason: 'auto' };
      return { allowed: !!(approvals && approvals[capability]), reason: 'approval' };
    }
  };

  // ---------- TECHNOLOGY RESEARCH FOUNDATION ----------
  var TechResearch = {
    _rate: function (f) { return typeof f === 'function' ? (f() || 0) : (f || 0); },
    evaluate: function (tech) {
      var score = { usefulness: this._rate(tech.usefulness), quality: this._rate(tech.quality),
        reliability: this._rate(tech.reliability), security: this._rate(tech.security),
        lowCost: tech.cost != null ? Math.max(0, 10 - (tech.cost || 0)) : 0,
        lowComplexity: tech.complexity != null ? Math.max(0, 10 - (tech.complexity || 0)) : 0 };
      var total = (score.usefulness * 3 + score.quality * 2 + score.reliability * 2 + score.security * 2 + score.lowCost + score.lowComplexity) / 11;
      var decision = total >= 7.5 ? 'ADOPT' : total >= 5.5 ? 'TEST' : total >= 3.5 ? 'WATCH' : total >= 1.5 ? 'IGNORE' : 'REPLACE';
      return { tech: tech.name || 'unknown', score: Math.round(total * 100) / 100, decision: decision, breakdown: score };
    }
  };

  // ---------- PERSONAL DECISION ENGINE (facts/assumptions/risks/options; challenges weak plans) ----------
  var DecisionEngine = {
    analyze: function (input) {
      var options = (input.options || []).map(function (o) {
        var ev = (o.value || 0) * (o.successProb || 0.5);
        var cost = o.cost || 0;
        return { option: o.option, expectedValue: Math.round(ev * 100) / 100, cost: cost, roi: Math.round((ev - cost) * 100) / 100, risk: o.risk || 'medium', why: o.why || '' };
      }).sort(function (a, b) { return b.roi - a.roi; });
      var best = options[0] || null;
      var challenges = [];
      if (best && best.roi <= 0) challenges.push('Best option has non-positive ROI — plan may be weak.');
      if (best && best.risk === 'high') challenges.push('Best option carries HIGH risk; consider mitigation.');
      if (!input.facts || !input.facts.length) challenges.push('No facts provided — assumptions dominate.');
      return {
        facts: input.facts || [], assumptions: input.assumptions || [], risks: input.risks || [],
        options: options, best: best, why: best ? best.why : '',
        nextStep: best ? ('Execute "' + best.option + '"') : 'none',
        challenge: challenges
      };
    }
  };

  // ---------- MEMORY EXPANSION (layers over existing SJMemory; secrets stripped) ----------
  var MemoryLayers = {
    layers: ['longterm', 'project', 'preferences', 'decisions', 'workflow', 'context'],
    remember: function (layer, content, meta) {
      if (this.layers.indexOf(layer) < 0) layer = 'context';
      var text = String(content || '').replace(/(pass\w*|token|api[_ ]?key|secret|credential)[=:]\s*\S+/gi, '$1=[REDACTED]');
      var m = base.Memory; if (!m || typeof m.remember !== 'function') return Promise.resolve({ ok: false, error: 'memory base unavailable' });
      return m.remember(layer, text, (meta && meta.source) || 'v7', (meta && meta.confidence) || 0.5);
    }
  };

  // ---------- SELF-AUDIT FOUNDATION (safe; production changes need approval) ----------
  var SelfAudit = {
    run: function (component) {
      return { target: component, stage: 'DETECT', problems: [], approved: false };
    },
    diagnose: function (a, problems) { a.problems = problems || []; a.stage = 'DIAGNOSE'; return a; },
    proposeFix: function (a, fix) { a.fix = fix; a.stage = 'PROPOSE_FIX'; return a; },
    test: function (a, ok) { a.testPassed = !!ok; a.stage = 'TEST'; return a; },
    requiresApproval: function (a) { return true; }, // production self-modification always needs human approval
    approve: function (a) { a.approved = true; a.stage = 'APPROVED'; return a; }
  };

  // expose
  base.ToolRegistry = ToolRegistry;
  base.SkillRegistry = SkillRegistry;
  base.TaskGraph = TaskGraph;
  base.Orchestrator = MasterOrchestrator;
  base.MasterOrchestrator = MasterOrchestrator;
  base.Autonomy = Autonomy;
  base.TechResearch = TechResearch;
  base.DecisionEngine = DecisionEngine;
  base.MemoryLayers = MemoryLayers;
  base.SelfAuditFull = SelfAudit;
  base.version = '0.2.0-full';
  base._full = true;
})();