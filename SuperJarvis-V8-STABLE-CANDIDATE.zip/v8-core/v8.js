// ============================================================
// SUPER JARVIS — V8 EXTENSION (AUTOMATION + INTEGRATIONS)
// Builds on existing SV7 + SJ.execute(). Additive, no second engine.
// All executable work -> window.executeS6Command -> SJ.execute().
// HONEST: no fake backend/credentials/web/browser/API. Unconnected -> BACKEND_REQUIRED.
// ============================================================
(function () {
  'use strict';
  var g = (typeof window !== 'undefined') ? window : global;
  if (g.SV8) return;
  var STATUS = { COMPLETED: 'completed', FAILED: 'failed', VERIFICATION_FAILED: 'verification_failed',
    BACKEND_REQUIRED: 'backend_required', TIMEOUT: 'timeout', CANCELLED: 'cancelled',
    NOT_IMPLEMENTED: 'not_implemented', NON_RECOVERABLE: 'non_recoverable', READY_FOR_RETRY: 'ready_for_retry' };

  function runThroughEngine(id, params, source) {
    if (typeof g.executeS6Command !== 'function') return Promise.resolve({ success: false, status: STATUS.FAILED, error: 'Core engine unavailable' });
    return g.executeS6Command(id, params || {}, source || 'v8');
  }
  function safeUrlCheck(u) {
    try { var x = new URL(String(u), g.location && g.location.href || 'https://local/'); return /^(javascript:|data:|vbscript:)/i.test(x.protocol) ? false : x.href; } catch (e) { return false; }
  }
  function stripSecrets(t) { return String(t == null ? '' : t).replace(/(pass\w*|token|api[_ ]?key|secret|credential|authorization|bearer)[=:]\s*\S+/gi, '$1=[REDACTED]'); }

  // ---------- INTEGRATION REGISTRY (B1/B2) ----------
  var IntegrationRegistry = {
    registry: {},
    register: function (id, meta) {
      if (!id) return null;
      var it = {
        id: id,
        provider: meta.provider || 'unknown',
        capabilities: meta.capabilities || [],
        inputs: meta.inputs || [],
        outputs: meta.outputs || ['result'],
        authRequired: !!meta.authRequired,
        authType: meta.authType || 'none',
        permissions: meta.permissions || 'none',
        risk: String(meta.risk || 'low').toUpperCase(),
        rateLimit: meta.rateLimit || 0,
        cost: meta.cost || 0,
        availability: meta.availability || 'backend_required', // honest default
        limitations: meta.limitations || [],
        verify: meta.verify || 'via_SJ_verifier',
        errorHandling: meta.errorHandling || 'bounded_retry',
        connected: !!meta.connected
      };
      this.registry[id] = it; return it;
    },
    get: function (id) { return this.registry[id] || null; },
    all: function () { return Object.keys(this.registry).map(function (k) { return this.registry[k]; }.bind(this)); }
  };

  // --- RATE LIMITER (B7) — bounded, no uncontrolled loop ---
  var RateLimiter = {
    _h: {}, _w: {}, _max: {},
    set: function (id, maxPerWindow, windowMs) { this._max[id] = { n: maxPerWindow, w: windowMs, _t: [] }; },
    allow: function (id) {
      var m = this._max[id]; if (!m) return true;
      var now = Date.now(); m._t = m._t.filter(function (t) { return now - t < m.w; });
      if (m._t.length >= m.n) return false; m._t.push(now); return true;
    },
    hits: function (id) { var m = this._max[id]; return m ? m._t.length : 0; }
  };

  // --- CREDENTIAL VAULT ABSTRACTION (B3) — never stores raw ---
  var CredentialVault = {
    store: function (name, _value) {
      // Security boundary: frontend-only cannot securely store raw credentials.
      return { ok: false, stored: false, name: name, status: 'SECURE_CREDENTIAL_BACKEND_REQUIRED', message: 'Raw credentials are never stored in localStorage/memory.' };
    },
    has: function () { return false; }, // no secure store available in frontend-only build
    status: function () { return 'SECURE_CREDENTIAL_BACKEND_REQUIRED'; }
  };

  // --- WEBHOOK / BROWSER AUTOMATION FOUNDATION (B4) — safe, backend-required ---
  var Webhook = {
    // Safe, permission-checked interface. No unrestricted browser automation.
    validate: function (url, permission) {
      var ok = safeUrlCheck(url); if (!ok) return { ok: false, error: 'Blocked or invalid URL' };
      if (permission && /^(HIGH|CRITICAL)$/.test(String(permission).toUpperCase())) return { ok: false, error: 'requires_approval' };
      return { ok: true, url: ok };
    },
    trigger: function (opts) {
      // No real browser backend in frontend-only build.
      return Promise.resolve({ status: STATUS.BACKEND_REQUIRED, integration: 'webhook', note: 'Browser automation backend not connected.' });
    }
  };

  // --- EXTERNAL API ADAPTER ABSTRACTION (B5) — honest ---
  var ApiAdapter = {
    preflight: function (integrationId) {
      var it = IntegrationRegistry.get(integrationId);
      if (!it) return { ok: false, status: STATUS.NOT_IMPLEMENTED, error: 'Unknown integration' };
      if (!it.connected) return { ok: false, status: STATUS.BACKEND_REQUIRED, integration: it.id, note: 'Not connected — no live backend.' };
      return { ok: true, it: it };
    },
    call: function (integrationId, params) {
      var p = this.preflight(integrationId);
      if (!p.ok) return Promise.resolve({ status: p.status, integration: integrationId, error: p.note || p.error });
      // Real connectivity would converge through SJ.execute here; none connected.
      return Promise.resolve({ status: STATUS.BACKEND_REQUIRED, integration: integrationId });
    }
  };

  // --- AUTOMATION ENGINE (B6) — extends existing SV7.TaskGraph; NO second engine ---
  var AutomationEngine = {
    workflow: function (name, steps) {
      // Build a TaskGraph via the existing SV7.TaskGraph; every step runs through SJ.execute.
      var graph = (g.SV7 && g.SV7.TaskGraph) ? g.SV7.TaskGraph.new('auto_' + name) : null;
      if (!graph) return { ok: false, error: 'SV7 TaskGraph unavailable' };
      (steps || []).forEach(function (s, i) {
        g.SV7.TaskGraph.add(graph, {
          id: 'a' + (i + 1), title: s.title || s.id, capability: s.capability || null,
          params: s.params || {}, dependsOn: s.dependsOn || [], risk: s.risk || 'low',
          retryLimit: (s.retryLimit != null ? s.retryLimit : 0), verify: s.verify !== false,
          condition: s.condition || null
        });
      });
      this._graphs[name] = graph; return graph;
    },
    _graphs: {},
    run: function (name, opts) {
      var graph = this._graphs[name];
      if (!graph) return Promise.resolve({ status: STATUS.FAILED, error: 'unknown workflow' });
      // Condition gates evaluated before execution by the graph runner.
      return g.SV7.TaskGraph.run(graph, opts || {}).then(function (res) {
        return { status: res.status, graph: graph, steps: Object.keys(graph.tasks).length };
      });
    }
  };

  // --- MONITORING (B8) — extends existing engine history; no secrets ---
  var Monitor = {
    record: function (entry) {
      // REUSE the existing centralized History writer (addHistory) so V8 monitoring does NOT
      // create a second history system or bypass the Core Engine lifecycle. addHistory writes
      // to sj_engine_history_v1 via readJSON/writeJSON with secret redaction + cap.
      var e = {
        commandId: entry.commandId || ('v8_' + Date.now().toString(36)),
        intent: entry.command || entry.workflow || entry.type || null,
        params: entry.params || {},
        source: 'v8',
        risk: entry.risk || 'low',
        status: entry.status || 'unknown',
        executionTime: entry.duration != null ? entry.duration : null,
        verified: !!entry.verified,
        error: stripSecrets(entry.error || '')
      };
      if (typeof g.addHistory === 'function') {
        try { g.addHistory(e); return e; } catch (err) { /* fall through to shared writeJSON */ }
      }
      if (typeof g.writeJSON === 'function') {
        try {
          var hist = []; try { hist = JSON.parse(g.localStorage.getItem('sj_engine_history_v1') || '[]'); } catch (err2) {}
          hist.unshift(e); if (hist.length > 100) hist.length = 100;
          g.writeJSON('sj_engine_history_v1', hist);
        } catch (err3) {}
      }
      return e;
    },
    summary: function () {
      var hist = []; try { hist = JSON.parse(g.localStorage.getItem('sj_engine_history_v1') || '[]'); } catch (e) {}
      var by = {}; hist.forEach(function (h) { by[h.status] = (by[h.status] || 0) + 1; });
      return { total: hist.length, byStatus: by };
    }
  };

  // --- SAFE AUTONOMY EXTENSION (B9) — reuse existing policy; never weaken ---
  var SafeAutonomy = {
    classify: function (risk) { return String(risk || 'low').toUpperCase(); },
    mayRunAuto: function (risk, policy) {
      var r = this.classify(risk); var p = policy || (g.SV7 && g.SV7.Autonomy && g.SV7.Autonomy.policy) || { LOW: 'auto', MEDIUM: 'auto', HIGH: 'approval', CRITICAL: 'approval' };
      return p[r] === 'auto';
    },
    gate: function (capability, approvals, risk) {
      var r = this.classify(risk);
      if (this.mayRunAuto(risk)) return { allowed: true, reason: 'auto' };
      return { allowed: !!(approvals && approvals[capability]), reason: 'approval' };
    }
  };

  // expose
  g.SV8 = { STATUS: STATUS, IntegrationRegistry: IntegrationRegistry, RateLimiter: RateLimiter,
    CredentialVault: CredentialVault, Webhook: Webhook, ApiAdapter: ApiAdapter,
    AutomationEngine: AutomationEngine, Monitor: Monitor, SafeAutonomy: SafeAutonomy,
    version: '0.1.0-v8' };
  // V8 runs on the single engine
  g.SV8.engine = 'SJ.execute()';
})();