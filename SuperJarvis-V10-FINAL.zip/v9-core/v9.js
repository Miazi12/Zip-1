// ============================================================
// SUPER JARVIS — V9 (MONEY-MAKING ENGINE FOUNDATION) v2
// STABILIZATION: all state-changing ops route through the EXISTING
// canonical engine: executeS6Command() -> SJ.execute() -> Router ->
// Planner -> Permission -> Executor/ACTION_REGISTRY -> Verifier ->
// State -> Memory -> History -> Result.
// NO second engine/pipeline/permission/verifier/memory/history.
// Pure calc helpers (ROI/risk/discovery/optimization) stay local.
// HONESTY: no income guarantee, no fake market/revenue/research/verification.
// ============================================================
(function () {
  'use strict';
  var g = (typeof window !== 'undefined') ? window : global;
  if (g.SV9) return;

  function runThroughEngine(op, params, source) {
    if (typeof g.executeS6Command === 'function') return g.executeS6Command(op, params || {}, source || 'v9');
    return Promise.resolve({ success: false, status: 'failed', error: 'Core engine unavailable' });
  }
  function UNKNOWN(v) { return (v === undefined || v === null || v === '') ? 'UNKNOWN' : v; }
  function gid(p) { return (p || 'v9') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function num(v) { var n = parseFloat(v); return isFinite(n) ? n : null; }

  var Cap = g.SV7 && g.SV7.CapabilityRegistry;
  var Mem = g.SJMemory || (g.SV7 && g.SV7.Memory);
  var Mon = g.SV8 && g.SV8.Monitor;

  var store = { goals: {}, opportunities: {}, strategies: [], plans: {}, revenue: [], experiments: [], decisions: [] };

  // Reuse existing project persistence (Memory + centralized History/Monitor). NOT a new system.
  function persist(entry) {
    if (Mem) { try { if (typeof Mem.remember === 'function') Mem.remember('project', JSON.stringify(entry), 'v9', 0.6); else if (typeof Mem.add === 'function') Mem.add('project', JSON.stringify(entry), 'v9', 0.6); } catch (e) {} }
    if (Mon && typeof Mon.record === 'function') { try { Mon.record({ command: entry.op || entry.kind || 'v9', source: 'v9', status: entry.status || 'completed', risk: entry.risk || 'low', verified: !!entry.verified }); } catch (e2) {} }
    return entry;
  }

  // ================= REGISTER V9 ACTIONS INTO EXISTING ACTION_REGISTRY =================
  var R = g.ACTION_REGISTRY;
  function registerAction(id, risk, description, exec, ver) {
    if (!R || !id) return;
    if (!R[id]) { R[id] = { id: id, description: description, risk: risk, reversible: false, requiresPermission: false, execute: exec, verify: ver }; }
  }

  // --- GOAL ---
  registerAction('v9_goal_create', 'LOW', 'Create/analyze a money goal',
    function (p) { var x = (p && p.goal) || p || {}; var goal = { goalId: gid('goal'), objective: UNKNOWN(x.objective), targetAmount: num(x.targetAmount), currency: UNKNOWN(x.currency), timeframe: UNKNOWN(x.timeframe), constraints: x.constraints || [], availableBudget: num(x.availableBudget), availableTime: num(x.availableTime), skills: x.skills || [], riskTolerance: UNKNOWN(x.riskTolerance), preferredMethods: x.preferredMethods || [], excludedMethods: x.excludedMethods || [], status: 'active', createdAt: Date.now() };
      if (!goal.objective || goal.objective === 'UNKNOWN') return { ok: false, error: 'objective required' };
      store.goals[goal.goalId] = goal; return { ok: true, result: goal }; },
    function (p, res) { return !!res && !!res.goalId && !!store.goals[res.goalId]; });

  // --- OPPORTUNITY ---
  registerAction('v9_opportunity_create', 'LOW', 'Define an opportunity',
    function (p) { var o = (p && p.opportunity) || p || {}; var opp = { opportunityId: o.id || gid('opp'), name: UNKNOWN(o.name), category: UNKNOWN(o.category), description: o.description || '', targetMarket: o.targetMarket || 'UNKNOWN', startupCost: num(o.startupCost), operatingCost: num(o.operatingCost), timeToFirstRevenue: o.timeToFirstRevenue || 'UNKNOWN', difficulty: o.difficulty || 'medium', requiredSkills: o.requiredSkills || [], requiredTools: o.requiredTools || [], scalability: o.scalability || 'medium', competition: o.competition || 'UNKNOWN', risk: o.risk || 'medium', automationPotential: o.automationPotential || 'low', expectedRevenueRange: o.expectedRevenueRange || 'UNKNOWN', confidence: o.confidence != null ? o.confidence : 0.5, assumptions: o.assumptions || [], dependencies: o.dependencies || [], backendRequirements: o.backendRequirements || [], evidence: o.evidence || 'SIMULATED', source: o.source || 'LOCAL', status: 'candidate' };
      store.opportunities[opp.opportunityId] = opp; return { ok: true, result: opp }; },
    function (p, res) { return !!res && !!res.opportunityId && !!store.opportunities[res.opportunityId]; });

  // --- STRATEGY ---
  registerAction('v9_strategy_create', 'LOW', 'Generate strategy from goal+opportunity',
    function (p) { var s = (p && p.strategy) || p || {}; var goal = store.goals[s.goalId], opp = store.opportunities[s.opportunityId];
      if (!goal || !opp) return { ok: false, error: 'goal+opportunity required' };
      var stages = [ { stage: 'validate-demand', objective: 'Validate demand', capability: null, risk: 'low' }, { stage: 'create-offer', objective: 'Define offer+pricing', capability: null, risk: 'low' }, { stage: 'min-deliverable', objective: 'Build minimum deliverable', capability: null, risk: 'low' }, { stage: 'acquire-customers', objective: 'Reach first customers', capability: null, risk: 'medium' }, { stage: 'deliver', objective: 'Deliver+feedback', capability: null, risk: 'medium' }, { stage: 'measure', objective: 'Track results', capability: 'revenue_tracking', risk: 'low' }, { stage: 'improve', objective: 'Optimize', capability: 'optimization_analysis', risk: 'low' }, { stage: 'scale', objective: 'Scale', capability: null, risk: 'high' } ];
      var strategy = { strategyId: gid('strat'), goalId: s.goalId, opportunityId: s.opportunityId, stages: stages, status: 'active' };
      store.strategies.push(strategy); return { ok: true, result: strategy }; },
    function (p, res) { return !!res && !!res.strategyId && store.strategies.some(function (x) { return x.strategyId === res.strategyId; }); });

  // --- PLAN (sequential dependency chain via existing TaskGraph) ---
  registerAction('v9_plan_create', 'LOW', 'Create plan/taskgraph from strategy (sequential deps)',
    function (p) { var s = (p && p.strategy) || (store.strategies[store.strategies.length - 1]);
      if (!s || !g.SV7 || !g.SV7.TaskGraph) return { ok: false, error: 'strategy or TaskGraph unavailable' };
      var graph = g.SV7.TaskGraph.new('plan_' + s.strategyId);
      s.stages.forEach(function (st, i) {
        // REAL sequential dependency: p1 -> no dep, pN -> dependsOn p(N-1)
        g.SV7.TaskGraph.add(graph, { id: 'p' + (i + 1), title: st.stage, capability: st.capability, params: { text: st.objective }, risk: st.risk, dependsOn: i > 0 ? ['p' + i] : [] });
      });
      store.plans[s.strategyId] = graph; return { ok: true, result: graph }; },
    function (p, res) { return !!res && !!res.tasks && store.plans[(p && p.strategy && p.strategy.strategyId) || (store.strategies[store.strategies.length - 1] && store.strategies[store.strategies.length - 1].strategyId)] === res; });

  // --- REVENUE (honest status; never fabricate external verification) ---
  registerAction('v9_revenue_record', 'MEDIUM', 'Record a user-reported revenue line',
    function (p) { var r = (p && p.record) || p || {};
      var rec = { recordId: gid('rev'), projectId: r.projectId || 'UNKNOWN', opportunityId: r.opportunityId || 'UNKNOWN', revenue: num(r.revenue) || 0, cost: num(r.cost) || 0, leads: num(r.leads) || 0, customers: num(r.customers) || 0, hoursSpent: num(r.hoursSpent) || 0, date: r.date || new Date().toISOString().slice(0, 10), notes: r.notes || '',
        // NEVER trust user-supplied verified:true. Only actual external/backend evidence can mark VERIFIED_EXTERNAL.
        source: (r.verified && r.externalEvidence) ? 'VERIFIED_EXTERNAL' : 'USER_REPORTED',
        verificationState: (r.verified && r.externalEvidence) ? 'VERIFIED_EXTERNAL' : 'UNVERIFIED', status: 'recorded' };
      store.revenue.push(rec); return { ok: true, result: rec }; },
    function (p, res) { return !!res && !!res.recordId && store.revenue.some(function (x) { return x.recordId === res.recordId; }); });

  // --- EXPERIMENT ---
  registerAction('v9_experiment_record', 'LOW', 'Record/close an experiment',
    function (p) { var h = (p && p.experiment) || p || {}; var e = { experimentId: gid('exp'), hypothesis: h.hypothesis || 'UNKNOWN', action: h.action || 'UNKNOWN', measure: h.measure || 'UNKNOWN', status: 'running', result: null, learning: null, risk: h.risk || 'low' }; store.experiments.push(e); return { ok: true, result: e }; },
    function (p, res) { return !!res && !!res.experimentId && store.experiments.some(function (x) { return x.experimentId === res.experimentId; }); });
  registerAction('v9_experiment_conclude', 'LOW', 'Conclude an experiment (canonical state change)',
    function (p) { var id = (p && p.experimentId) || (p && p.experiment && p.experiment.experimentId); var e = null; store.experiments.forEach(function (x) { if (x.experimentId === id) e = x; }); if (!e) return { ok: false, error: 'not found' }; e.result = (p && p.result) || null; e.status = 'completed'; e.learning = 'recorded actual result'; return { ok: true, result: e }; },
    function (p, res) { return !!res && !!res.experimentId && res.status === 'completed' && store.experiments.some(function (x) { return x.experimentId === res.experimentId && x.status === 'completed'; }); });

  // ================= GOAL ENGINE (async via canonical engine) =================
  var GoalEngine = {
    create: function (g0) { return runThroughEngine('v9_goal_create', { goal: g0 }, 'v9').then(function (r) { if (r.success && r.verified) persist({ op: 'goal', kind: 'goal', goalId: r.result.goalId, risk: 'low', verified: true }); return { ok: r.success === true && r.verified === true, goal: r.result, status: r.status, verified: !!r.verified }; }); },
    get: function (id) { return store.goals[id] || null; },
    list: function () { return Object.keys(store.goals).map(function (k) { return store.goals[k]; }); },
    missing: function (id) { var goal = this.get(id); if (!goal) return ['not_found']; var m = []; if (goal.targetAmount == null) m.push('targetAmount'); if (goal.timeframe === 'UNKNOWN') m.push('timeframe'); if (goal.riskTolerance === 'UNKNOWN') m.push('riskTolerance'); return m; }
  };

  // ================= OPPORTUNITY ENGINE =================
  var OpportunityEngine = {
    _local: { freelancing: { name: 'Freelancing (web/app/design/writing)', category: 'freelancing', startupCost: 'low', timeToFirstRevenue: 'days', difficulty: 'low', competition: 'medium', scalability: 'low', risk: 'low', source: 'LOCAL' }, aiAutomation: { name: 'AI automation services', category: 'AI automation services', startupCost: 'low', timeToFirstRevenue: 'weeks', difficulty: 'medium', competition: 'medium', scalability: 'medium', risk: 'medium', source: 'SIMULATED' }, content: { name: 'Content business', category: 'content business', startupCost: 'low', timeToFirstRevenue: 'months', difficulty: 'medium', competition: 'high', scalability: 'high', risk: 'medium', source: 'SIMULATED' }, digitalProducts: { name: 'Digital products', category: 'digital products', startupCost: 'low', timeToFirstRevenue: 'weeks', difficulty: 'medium', competition: 'medium', scalability: 'high', risk: 'medium', source: 'SIMULATED' }, affiliate: { name: 'Affiliate marketing', category: 'affiliate models', startupCost: 'low', timeToFirstRevenue: 'months', difficulty: 'medium', competition: 'high', scalability: 'medium', risk: 'medium', source: 'SIMULATED' }, leadGen: { name: 'Lead generation for local businesses', category: 'lead generation', startupCost: 'medium', timeToFirstRevenue: 'weeks', difficulty: 'high', competition: 'low', scalability: 'medium', risk: 'medium', source: 'SIMULATED' }, software: { name: 'Software / SaaS tools', category: 'software/tools', startupCost: 'medium', timeToFirstRevenue: 'months', difficulty: 'high', competition: 'medium', scalability: 'high', risk: 'high', source: 'SIMULATED' }, ecommerce: { name: 'Legitimate ecommerce', category: 'legitimate ecommerce', startupCost: 'medium', timeToFirstRevenue: 'weeks', difficulty: 'high', competition: 'high', scalability: 'medium', risk: 'high', source: 'SIMULATED' } },
    localLibrary: function () { var s = this; return Object.keys(s._local).map(function (k) { var o = s._local[k]; return { id: k, name: o.name, category: o.category, risk: o.risk, startupCost: o.startupCost, source: o.source }; }); },
    discover: function (opts) { var cats = opts && opts.categories; var out = this.localLibrary().filter(function (o) { return !cats || cats.indexOf(o.category) > -1; }); return { ok: true, opportunities: out, source: 'LOCAL_SIMULATED', backend: 'BACKEND_REQUIRED' }; },
    define: function (o) { return runThroughEngine('v9_opportunity_create', { opportunity: o }, 'v9').then(function (r) { return { ok: r.success === true && r.verified === true, opportunity: r.result, status: r.status, verified: !!r.verified }; }); },
    get: function (id) { return store.opportunities[id] || null; },
    _find: function (id) { return store.opportunities[id]; }
  };

  // ================= ROI / RISK (pure heuristic, honestly labelled) =================
  var ROIEngine = {
    score: function (o, goal) {
      o = o || {};
      var tf = o.timeToFirstRevenue === 'days' ? 1 : o.timeToFirstRevenue === 'weeks' ? 0.8 : o.timeToFirstRevenue === 'months' ? 0.55 : 0.5;
      var df = o.difficulty === 'low' ? 1 : o.difficulty === 'medium' ? 0.8 : 0.55;
      var sc = o.scalability === 'high' ? 1 : o.scalability === 'medium' ? 0.8 : 0.6;
      var cm = o.competition === 'low' ? 1 : o.competition === 'medium' ? 0.8 : 0.6;
      var rs = o.risk === 'low' ? 1 : o.risk === 'medium' ? 0.75 : 0.5;
      var au = o.automationPotential === 'high' ? 1.05 : o.automationPotential === 'medium' ? 0.95 : 0.9;
      var score = Math.round((0.6 * tf + 0.7 * df + 0.5 * sc + 0.4 * cm + 0.6 * rs) * au * 100) / 100;
      return { opportunity: o.name || o.opportunityId, score: score, scoringModel: 'HEURISTIC_LOCAL_SIMULATED', dataStatus: 'DATA_REQUIRED/BACKEND_REQUIRED', confidence: typeof o.confidence === 'number' ? o.confidence : 0.5, facts: { resourceKnown: num(o.startupCost) != null, targetGiven: !!(goal && goal.targetAmount != null), source: o.source || 'SIMULATED' }, assumptions: ['market demand', 'price point', 'conversion', 'available time'], risks: [o.risk || 'medium', 'competition', 'time-to-first-revenue'] };
    },
    riskScore: function (o) { var r = (o && o.risk) || 'medium'; return r === 'low' ? 1 : r === 'medium' ? 2 : 3; }
  };

  // ================= FEASIBILITY / WEAK-OPTION REJECTION =================
  var FeasibilityEngine = {
    evaluate: function (opp, goal) {
      opp = opp || {}; goal = goal || {};
      var hard = [], unknown = [];
      var budget = num(goal.availableBudget);
      var goalMonths = goal.timeframe === 'days' ? 0.1 : goal.timeframe === 'weeks' ? 0.75 : goal.timeframe === 'months' ? 3 : null;
      var monthsOf = function (v) { return v === 'days' ? 0.1 : v === 'weeks' ? 0.75 : v === 'months' ? 3 : null; };
      var facts = { targetAmount: num(goal.targetAmount), timeframe: goal.timeframe || null, availableBudget: budget, availableTime: goal.availableTime != null ? num(goal.availableTime) : null, skills: goal.skills || [], riskTolerance: goal.riskTolerance || null, startupCost: opp.startupCost || null, difficulty: opp.difficulty || null, competition: opp.competition || null, scalability: opp.scalability || null, automationPotential: opp.automationPotential || null, timeToFirstRevenue: opp.timeToFirstRevenue || null, source: opp.source || 'SIMULATED', confidenceGiven: typeof opp.confidence === 'number' ? opp.confidence : null };
      if (goalMonths != null && opp.timeToFirstRevenue) { var om = monthsOf(opp.timeToFirstRevenue); if (om != null && om > goalMonths) hard.push('timeframe: opportunity (' + opp.timeToFirstRevenue + ') slower than goal (' + goal.timeframe + ')'); }
      if (budget != null && opp.startupCost) { if (opp.startupCost === 'medium' && budget < 2000) hard.push('startup cost (medium) exceeds budget'); else if (opp.startupCost === 'high' && budget < 5000) hard.push('startup cost (high) exceeds budget'); else if (opp.startupCost === 'low' && budget < 200) hard.push('startup cost (low) exceeds budget'); }
      if (goal.riskTolerance && opp.risk) { if ((opp.risk === 'high' || opp.risk === 'medium') && goal.riskTolerance === 'low') hard.push('risk (' + opp.risk + ') exceeds tolerance (low)'); }
      if (opp.difficulty === 'high' && goal.availableTime != null && num(goal.availableTime) < 5) hard.push('difficulty (high) needs more available time');
      if (opp.competition === 'high' && goalMonths != null && goalMonths <= 0.75) hard.push('high competition unlikely within short timeframe');
      if (goal.skills && opp.requiredSkills && goal.skills.length && opp.requiredSkills.length && !opp.requiredSkills.some(function (sk) { return goal.skills.indexOf(sk) > -1; })) hard.push('missing required skill(s): ' + opp.requiredSkills.join(','));
      if (goal.excludedMethods && opp.category && goal.excludedMethods.length && goal.excludedMethods.indexOf(opp.category) > -1) hard.push('category excluded by user');
      var assumptions = [];
      if (opp.timeToFirstRevenue) assumptions.push('time-to-first-revenue estimated as ' + opp.timeToFirstRevenue);
      if (opp.startupCost) assumptions.push('startup cost estimated as ' + opp.startupCost);
      if (opp.risk) assumptions.push('risk estimated as ' + opp.risk);
      if (opp.source === 'SIMULATED') assumptions.push('opportunity parameters are SIMULATED/LOCAL, not market data');
      var risks = [];
      if (opp.risk) risks.push('risk: ' + opp.risk);
      if (opp.competition) risks.push('competition: ' + opp.competition);
      if (opp.scalability === 'low') risks.push('low scalability');
      if (opp.timeToFirstRevenue === 'months') risks.push('late to first revenue');
      if (goal.targetAmount == null) unknown.push('target amount');
      if (goal.timeframe == null) unknown.push('timeframe');
      if (budget == null) unknown.push('available budget');
      if (opp.startupCost == null) unknown.push('startup cost');
      if (opp.risk == null) unknown.push('opportunity risk');
      if (opp.timeToFirstRevenue == null) unknown.push('time-to-first-revenue');
      if (opp.confidence == null) unknown.push('opportunity confidence/evidence');
      var feasible = hard.length === 0;
      var status = hard.length ? 'INFEASIBLE' : (unknown.length ? 'INSUFFICIENT_DATA' : 'FEASIBLE');
      var confidence = feasible ? Math.max(0.1, 1 - (unknown.length * 0.22)) * (typeof opp.confidence === 'number' ? (0.5 + (opp.confidence / 2)) : 1) : 0;
      confidence = Math.round(confidence * 100) / 100;
      return { feasible: feasible, status: status, reason: hard.join('; ') || '', facts: facts, assumptions: assumptions, risks: risks, unknown: unknown, confidence: confidence, missing: unknown, explain: { whyPassed: hard.length === 0 ? 'no hard constraint conflict' : '', whyFailed: hard.join('; '), missingInfo: unknown } };
    }
  };

  // ================= STRATEGY ENGINE =================
  var StrategyEngine = {
    generate: function (goal, opp) { if (!goal || !opp) return Promise.resolve({ ok: false, error: 'goal+opportunity required' }); return runThroughEngine('v9_strategy_create', { goalId: goal.goalId, opportunityId: opp.oppId || opp.opportunityId }, 'v9').then(function (r) { return { ok: r.success === true && r.verified === true, strategy: r.result, status: r.status, verified: !!r.verified }; }); },
    list: function () { return store.strategies; }
  };

  // ================= PLAN ENGINE (sequential deps via existing TaskGraph) =================
  var PlanEngine = {
    create: function (strategy) { if (!strategy) return Promise.resolve({ ok: false, error: 'strategy required' }); return runThroughEngine('v9_plan_create', { strategy: strategy }, 'v9').then(function (r) { return { ok: r.success === true && r.verified === true, plan: r.result, status: r.status, verified: !!r.verified }; }); },
    get: function (id) { return store.plans[id] || null; }
  };

  // ================= REVENUE TRACKER (honest status) =================
  var RevenueTracker = {
    record: function (rec) { return runThroughEngine('v9_revenue_record', { record: rec }, 'v9').then(function (r) { if (r.success && r.verified) persist({ op: 'revenue', kind: 'revenue', recordId: r.result.recordId, status: r.result.status, verified: true }); return { ok: r.success === true && r.verified === true, record: r.result, status: r.status, verified: !!r.verified }; }); },
    summary: function () { var tr = 0, tc = 0, unver = 0, ext = 0, other = 0, userReported = 0; store.revenue.forEach(function (r) { tr += r.revenue; tc += r.cost; var vs = r.verificationState || r.status; if (vs === 'UNVERIFIED') unver++; else if (vs === 'VERIFIED_EXTERNAL') ext++; else other++; if (r.source === 'USER_REPORTED') userReported++; }); return { records: store.revenue.length, totalRevenue: tr, totalCost: tc, profit: tr - tc, userReported: userReported, unverified: unver, externallyVerified: ext, other: other, labels: ['USER_REPORTED/UNVERIFIED', 'VERIFIED_EXTERNAL'] }; }
  };

  // ================= EXPERIMENT ENGINE =================
  var ExperimentEngine = {
    start: function (h) { return runThroughEngine('v9_experiment_record', { experiment: h }, 'v9').then(function (r) { return { ok: r.success === true && r.verified === true, experiment: r.result, status: r.status, verified: !!r.verified }; }); },
    conclude: function (id, result) { return runThroughEngine('v9_experiment_conclude', { experimentId: id, result: result || null }, 'v9').then(function (r) { return { ok: r.success === true && r.verified === true, experiment: r.result, status: r.status, verified: !!r.verified }; }); },
    list: function () { return store.experiments; }
  };

  // ================= OPTIMIZATION ENGINE =================
  var OptimizationEngine = {
    analyze: function () { var rev = RevenueTracker.summary(); var exps = ExperimentEngine.list(); var worked = [], failed = []; exps.forEach(function (e) { if (e.result && e.result.positive) worked.push(e); else if (e.result && !e.result.positive) failed.push(e); }); return { ok: true, optimization: { bottleneck: exps.length ? 'from_recorded_data' : 'no_data', nextExperiment: exps.length ? 'from_recorded_data' : 'start_an_experiment', worked: worked, failed: failed, profit: rev.profit, unverified: rev.unverified, externallyVerified: rev.externallyVerified, source: rev.records ? 'LOCAL' : 'NO_RECORDED_DATA' } }; }
  };

  // ================= MONEY ORCHESTRATOR (feasibility-gated; uses engine for executable steps) =================
  var MoneyOrchestrator = {
    run: function (goalInput, opts) {
      opts = opts || {};
      return GoalEngine.create(goalInput).then(function (g0) {
        if (!g0.ok) return { status: 'failed', error: g0.error || 'goal failed' };
        var goal = g0.goal;
        var discovered = OpportunityEngine.discover(opts);
        var ranked = [];
        var deferred = (discovered.opportunities || []).map(function (d) {
          return OpportunityEngine.define({ id: d.id, name: d.name, category: d.category, risk: d.risk, startupCost: d.startupCost, timeToFirstRevenue: d.timeToFirstRevenue, difficulty: d.difficulty, competition: d.competition, scalability: d.scalability, source: d.source }).then(function (def) {
            if (!def.ok) return null;
            var opp = def.opportunity;
            var f = FeasibilityEngine.evaluate(opp, goal);
            var sc = ROIEngine.score(opp, goal);
            return { opp: opp, score: sc, feasible: f.feasible, status: f.status, confidence: f.confidence, missing: f.missing, infeasibleReason: f.reason };
          });
        });
        return Promise.all(deferred).then(function (rows) {
          rows = rows.filter(Boolean);
          var feasible = rows.filter(function (r) { return r.feasible; });
          // Prefer full-data FEASIBLE options; a high-scoring INFEASIBLE option is never selected.
          function prec(a, b) { var aF = a.status === 'FEASIBLE' ? 1 : 0; var bF = b.status === 'FEASIBLE' ? 1 : 0; if (aF !== bF) return bF - aF; return (b.score.score || 0) - (a.score.score || 0); }
          var selected = feasible.length ? feasible.slice().sort(prec)[0] : null;
          if (!selected) { return { status: 'NO_FEASIBLE_OPTION', reason: 'All candidates infeasible/missing constraints.', ranked: rows }; }
          return StrategyEngine.generate(goal, selected.opp).then(function (st) {
            if (!st.ok) return { status: 'failed', error: 'strategy failed' };
            return PlanEngine.create(st.strategy).then(function (pl) {
              return { status: pl.ok ? 'completed' : 'failed', goal: goal, best: selected.opp.name, feasible: selected.feasible, feasibilityStatus: selected.status, confidence: selected.confidence, strategy: st.strategy, plan: pl.ok ? pl.plan : null, decision: null, ranked: rows, backend: 'LOCAL/BACKEND_REQUIRED' };
            });
          });
        });
      });
    }
  };

  // CAPABILITY/AGENT registration via existing registries (extend, not duplicate)
  var caps = { goal_analysis: { name: 'Goal analysis', category: 'business', description: 'Define/analyze a money goal', risk: 'LOW', availability: 'available' }, opportunity_discovery: { name: 'Opportunity discovery', category: 'business', description: 'Local knowledge opportunities', risk: 'LOW', availability: 'available' }, roi_analysis: { name: 'ROI analysis', category: 'business', description: 'Score opportunity ROI/risk (heuristic)', risk: 'LOW', availability: 'available' }, strategy_generation: { name: 'Strategy generation', category: 'business', description: 'Build a strategy', risk: 'LOW', availability: 'available' }, business_plan: { name: 'Business plan', category: 'business', description: 'Plan/taskgraph from strategy', risk: 'LOW', availability: 'available' }, revenue_tracking: { name: 'Revenue tracking', category: 'business', description: 'Record USER_REPORTED revenue', risk: 'MEDIUM', availability: 'available' }, experiment_tracking: { name: 'Experiment tracking', category: 'business', description: 'Record/close experiments', risk: 'LOW', availability: 'available' }, optimization_analysis: { name: 'Optimization analysis', category: 'business', description: 'Optimize from recorded data', risk: 'LOW', availability: 'available' } };
  if (Cap && typeof Cap.register === 'function') { Object.keys(caps).forEach(function (id) { try { Cap.register(id, caps[id]); } catch (e) {} }); }
  var Agent = g.SV7 && g.SV7.AgentRegistry;
  if (Agent && Agent.list) { try { Agent.list.v9_business = { id: 'v9_business', desc: 'V9 business analysis agent', tools: ['goal_analysis', 'roi_analysis'], status: 'AVAILABLE_LOCAL' }; Agent.list.v9_opportunity = { id: 'v9_opportunity', desc: 'V9 opportunity agent', tools: ['opportunity_discovery'], status: 'AVAILABLE_LOCAL' }; Agent.list.v9_strategy = { id: 'v9_strategy', desc: 'V9 strategy agent', tools: ['strategy_generation', 'business_plan'], status: 'AVAILABLE_LOCAL' }; } catch (e) {} }

  g.SV9 = { engine: 'SJ.execute()', version: '0.2.0-v9', GoalEngine: GoalEngine, OpportunityEngine: OpportunityEngine, ROIEngine: ROIEngine, FeasibilityEngine: FeasibilityEngine, StrategyEngine: StrategyEngine, PlanEngine: PlanEngine, RevenueTracker: RevenueTracker, ExperimentEngine: ExperimentEngine, OptimizationEngine: OptimizationEngine, MoneyOrchestrator: MoneyOrchestrator, _store: store };
})();