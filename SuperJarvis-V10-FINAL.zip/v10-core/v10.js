// ============================================================
// SUPER JARVIS — V10 EXTENSION (BACKEND INTEGRATION + REAL EXECUTION UPGRADE)
// Additive layer on existing V6.4/V7/V8/V9. NO second engine/router/permission/
// executor/verifier/memory/history. All executable work -> executeS6Command -> SJ.execute().
// HONEST: no connected provider in base => research/market/execution/integration return
// BACKEND_REQUIRED / NOT_IMPLEMENTED / UNKNOWN. Nothing fabricated.
// ============================================================
(function () {
  'use strict';
  var g = (typeof window !== 'undefined') ? window : global;
  if (g.SV10) return;

  var ST = (g.SV8 && g.SV8.STATUS) || {};
  var DONE = ST.COMPLETED || 'completed';
  var FR = ST.BACKEND_REQUIRED || 'backend_required';
  var NI = ST.NOT_IMPLEMENTED || 'not_implemented';
  var capReg = g.SV7 && g.SV7.CapabilityRegistry;
  var Mem = g.SJMemory || (g.SV7 && g.SV7.Memory);
  var Mon = g.SV8 && g.SV8.Monitor;
  var Integ = g.SV8 && g.SV8.IntegrationRegistry;
  var Decision = g.SV7 && g.SV7.DecisionEngine;
  var V9 = g.SV9;

  function runThroughEngine(op, params, source) {
    if (typeof g.executeS6Command === 'function') return g.executeS6Command(op, params || {}, source || 'v10');
    return Promise.resolve({ success: false, status: 'failed', error: 'Core engine unavailable' });
  }
  function now() { return Date.now(); }
  function UNK(v) { return (v === undefined || v === null || v === '') ? 'UNKNOWN' : v; }
  function num(v) { var n = parseFloat(v); return isFinite(n) ? n : null; }
  function stripSecrets(t) { return String(t == null ? '' : t).replace(/(pass\w*|token|api[_ ]?key|secret|credential|authorization|bearer)[=:]\s*\S+/gi, '$1=[REDACTED]'); }

  // ================= PHASE 1 — PROVENANCE / NORMALIZATION =================
  var Provenance = {
    SOURCE_TYPES: ['LIVE_EXTERNAL', 'USER_REPORTED', 'LOCAL', 'SIMULATED', 'HEURISTIC', 'UNKNOWN'],
    attach: function (data, o) {
      var r = {}; for (var k in data) if (Object.prototype.hasOwnProperty.call(data, k)) r[k] = data[k];
      var st = o.sourceType || data.sourceType || 'UNKNOWN';
      r.sourceType = st;
      r.source = UNK(o.source || data.source);
      r.evidence = o.evidence != null ? o.evidence : (data.evidence != null ? data.evidence : null);
      r.confidence = (typeof o.confidence === 'number') ? o.confidence : (typeof data.confidence === 'number' ? data.confidence : 0.5);
      r.observedAt = o.observedAt || data.observedAt || now();
      r.expiresAt = o.expiresAt || data.expiresAt || null;
      r.assumptions = o.assumptions || data.assumptions || [];
      r.risks = o.risks || data.risks || [];
      r.verificationState = this.classify(st, !!o.evidence, !!o.externalVerified, r.verified === true).verificationState;
      return r;
    },
    // Never USER_REPORTED -> EXTERNAL_VERIFIED without real evidence.
    classify: function (st, hasEvidence, externalVerified, claimed) {
      if (st === 'LIVE_EXTERNAL') return { verificationState: (hasEvidence && externalVerified) ? 'EXTERNAL_VERIFIED' : (hasEvidence ? 'VERIFIED_EXTERNAL' : 'UNVERIFIED'), note: 'live external evidence' };
      if (st === 'USER_REPORTED') return { verificationState: (hasEvidence && externalVerified) ? 'VERIFIED_EXTERNAL' : 'UNVERIFIED', note: 'user-reported; unverified unless real external evidence' };
      return { verificationState: 'UNVERIFIED', note: st + ' is not externally verified' };
    },
    label: function (r) { return r.sourceType + ':' + r.verificationState; }
  };

  // ================= PHASE 2 — RESEARCH PROVIDER (honest, no fake provider) =================
  function ResearchResult(query, provider, status, limitations) {
    return { query: query, source: (provider && provider.source) || 'none', timestamp: now(), evidence: null,
      confidence: (provider && provider.confidence) || 0, limitations: limitations || [], status: status };
  }
  var ResearchProvider = {
    providers: {},
    register: function (id, meta) { this.providers[id] = { id: id, source: meta.source || id, live: !!meta.live, connected: !!meta.connected, capabilities: meta.capabilities || [], confidence: meta.confidence != null ? meta.confidence : 0.6, fetch: (typeof meta.fetch === 'function') ? meta.fetch : null }; return this.providers[id]; },
    connected: function () { var a = Object.keys(this.providers).map(function (k) { return this.providers[k]; }.bind(this)); return a.filter(function (p) { return p.live && p.connected; }); },
    // RESEARCH ACTION: query -> provider -> normalized evidence. No connected provider => BACKEND_REQUIRED.
    query: function (category, q) {
      var live = this.connected().filter(function (p) { return p.capabilities.indexOf(category) > -1; });
      if (!live.length) return ResearchResult(q, null, FR, ['no connected live research provider for "' + category + '"']);
      var p = live[0];
      if (!p.fetch) return ResearchResult(q, p, NI, ['provider connected but fetch() not implemented']);
      try {
        var out = p.fetch(category, q); // real provider would return real evidence here
        if (!out || !out.evidence) return ResearchResult(q, p, FR, ['provider returned no evidence']);
        return { query: q, source: p.source, timestamp: new Date(), evidence: out.evidence, confidence: p.confidence, limitations: out.limitations || [], status: 'LIVE' };
      } catch (e) { return ResearchResult(q, p, ST.FAILED || 'failed', ['provider fetch failed']); }
    },
    status: function (category) { return this.connected().filter(function (p) { return p.capabilities.indexOf(category) > -1; }).length ? 'LIVE' : FR; }
  };

  // ================= PHASE 3 — MARKET VALIDATION (opportunity evidence tiers) =================
  var MarketValidation = {
    // Local library stays LOCAL/SIMULATED. External tier requires a live provider (none in base).
    validate: function (opp, providerStatus) {
      if (!opp) return { status: FR, tier: 'backend_required', evidence: null, confidence: 'UNKNOWN' };
      if (providerStatus === 'LIVE') return { status: 'LIVE', tier: 'externally_evidenced', evidence: 'from_connected_provider', confidence: 0.7 };
      if (opp.sourceType === 'LOCAL' || opp.source === 'LOCAL') return { status: FR, tier: 'heuristic_only', evidence: null, confidence: 0.3, note: 'local/simulated knowledge; live market validation requires a connected provider (BACKEND_REQUIRED)' };
      return { status: FR, tier: 'partially_evidenced', evidence: null, confidence: 0.4, note: 'heuristic only' };
    }
  };

  // ================= PHASE 5 — EXECUTION ADAPTERS (no direct UI->provider) =================
  var ExecutionAdapter = {
    categories: ['research', 'ai_model', 'email', 'messaging', 'browser_automation', 'content_publishing', 'finance_data', 'payment_verification', 'cloud_storage'],
    execute: function (category, op) {
      if (this.categories.indexOf(category) < 0) return { status: NI, error: 'unknown integration category: ' + category };
      var p = ResearchProvider.connected().filter(function (x) { return x.capabilities.indexOf(category) > -1; });
      if (!p.length) return { status: FR, category: category, op: op, detail: 'integration not connected — BACKEND_REQUIRED', result: null };
      if (!p[0].fetch) return { status: NI, category: category, op: op, detail: 'connected but not implemented' };
      try { var r = p[0].fetch(category, op); return r; } catch (e) { return { status: ST.FAILED || 'failed', category: category, op: op, detail: 'provider error' }; }
    },
    available: function (category) { return ResearchProvider.status(category) === 'LIVE'; }
  };

  // ================= PHASE 6 — EXTERNAL VERIFICATION (two explicit classes) =================
  var ExternalVerifier = {
    // INTERNAL_VERIFIED: verified by local system state.
    internal: function (record) {
      if (!record) return false;
      if (record.kind === 'task') return !!record.exists;
      if (record.kind === 'experiment' && record.status === 'completed') return true;
      if (record.kind === 'strategy' && record.strategyId) return true;
      return false;
    },
    // EXTERNAL_VERIFIED: only through real external evidence.
    external: function (record) {
      if (!record) return false;
      return record.sourceType === 'LIVE_EXTERNAL' && !!record.evidence && record.verificationState === 'VERIFIED_EXTERNAL' || record.verificationState === 'EXTERNAL_VERIFIED';
    },
    classify: function (record) {
      if (this.external(record)) return 'EXTERNAL_VERIFIED';
      if (this.internal(record)) return 'INTERNAL_VERIFIED';
      return 'UNVERIFIED';
    }
  };

  // ================= PHASE 8 — FAILURE + RECOVERY =================
  var Recovery = {
    retryable: [FR, 'timeout', 'cancelled', 'verification_failed'],
    classify: function (res) {
      var st = (res && res.status) || ST.FAILED || 'failed';
      if (res && res.nonRecoverable) return 'NON_RECOVERABLE';
      if (this.retryable.indexOf(st) > -1) return 'READY_FOR_RETRY';
      if (st === 'failed' || st === FR) return 'READY_FOR_RETRY';
      return 'NON_RECOVERABLE';
    },
    // Do NOT auto-retry HIGH/CRITICAL without explicit permission.
    retry: function (res, risk, permitted) {
      var cl = this.classify(res);
      if (cl !== 'READY_FOR_RETRY') return { status: 'NON_RECOVERABLE', action: 'no_retry', reason: cl };
      if ((risk === 'HIGH' || risk === 'CRITICAL') && !permitted) return { status: 'CANCELLED', action: 'requires_permission', reason: 'high/critical retry needs explicit confirmation' };
      return { status: 'READY_FOR_RETRY', action: 'retry', reason: 'retryable, safe' };
    }
  };

  // ================= PHASE 9 — EXPERIMENT LEARNING (structured, evidence-based) =================
  var ExperimentV10 = {
    // Reuses existing experiment state + canonical conclude; derives structured learning from actual recorded data.
    learn: function (exp, actual) {
      var expected = exp && exp.expected; var metric = (exp && exp.measure) || 'measure'; var actualVal = (actual && actual.metric) != null ? actual.metric : null;
      var verdict = 'UNKNOWN';
      if (expected != null && actualVal != null) verdict = actualVal > expected ? 'positive' : actualVal < expected ? 'negative' : 'neutral';
      return { hypothesis: (exp && exp.hypothesis) || 'UNKNOWN', action: (exp && exp.action) || 'UNKNOWN', metric: metric, expected: expected, actual: actualVal,
        verdict: verdict, evidence: (actual && actual.evidence) || null, learning: (expected != null && actualVal != null) ? ('metric ' + metric + ' actual=' + actualVal + ' vs expected=' + expected + ' -> ' + verdict) : ('no actual metric recorded -> evidence ' + (actual && actual.evidence ? 'present' : 'missing')), evidenceMissing: !(actual && actual.evidence) };
    },
    conclude: function (id, actual) {
      var exps = V9 && V9.ExperimentEngine;
      if (!exps) return Promise.resolve({ ok: false, error: 'ExperimentEngine unavailable' });
      return exps.conclude(id, actual).then(function (r) { if (!r.ok) return r; var lr = this.learn(r.experiment, actual); return { ok: true, experiment: r.experiment, learning: lr }; }.bind(this));
    }
  };

  // ================= PHASE 4/10 — DECISION + MONEY ORCHESTRATOR V10 =================
  var MoneyOrchestratorV10 = {
    run: function (goalInput, opts) {
      opts = opts || {};
      if (!V9) return Promise.resolve({ status: FR, error: 'V9 base unavailable' });
      return V9.MoneyOrchestrator.run(goalInput, opts).then(function (base) {
        if (base.status !== DONE && base.status !== 'completed') return { status: base.status, error: base.error || base.reason, decision: null };
        var ranked = base.ranked || [];
        var feasible = ranked.filter(function (r) { return r.feasible; });
        var unknowns = [];
        if (!goalInput || goalInput.targetAmount == null) unknowns.push('target amount');
        if (!goalInput || !goalInput.timeframe) unknowns.push('timeframe');
        var options = feasible.map(function (r) { var s = (r.score && r.score.score) || 0; return { option: r.opp ? r.opp.name : 'option', value: s, successProb: (r.confidence != null ? r.confidence : 0.5), cost: 0, risk: (r.opp && r.opp.risk) || 'medium', why: 'heuristic ROI ' + s }; });
        var decision = null;
        if (Decision && Decision.analyze) decision = Decision.analyze({ facts: feasible.length ? ['heuristic ROI of feasible candidates'] : [], assumptions: ['opportunity params SIMULATED/HEURISTIC'], risks: feasible.map(function (r) { return (r.opp && r.opp.risk) || 'medium'; }), options: options });
        var decisionObj = {
          facts: (decision && decision.facts) || [], assumptions: (decision && decision.assumptions) || [], risks: (decision && decision.risks) || [],
          unknowns: unknowns, options: options, selected: base.best || null, reason: (decision && decision.why) || (base.best ? 'heuristic best feasible' : 'none'),
          confidence: base.confidence != null ? base.confidence : (unknowns.length ? 0.4 : 0.6),
          evidenceStatus: unknowns.length ? 'INSUFFICIENT_DATA' : 'PARTIAL', backend: 'LOCAL/BACKEND_REQUIRED', incomeGuarantee: false
        };
        return {
          status: base.status, goal: base.goal, best: base.best, feasible: base.feasible, strategy: base.strategy, plan: base.plan,
          decision: decisionObj, evidence: decisionObj.evidenceStatus, localFacts: (decisionObj.facts), externalFacts: [], assumptions: decisionObj.assumptions, risks: decisionObj.risks, unknowns: decisionObj.unknowns,
          confidence: decisionObj.confidence, backend: decisionObj.backend, package: decisionObj
        };
      });
    }
  };

  // ================= PHASE 7 — PERSISTENCE (existing infrastructure; LOCAL scope; no secrets) =================
  var PersistenceV10 = {
    scope: 'LOCAL',
    persist: function (entity) {
      var e = {}; for (var k in entity) if (Object.prototype.hasOwnProperty.call(entity, k)) e[k] = entity[k];
      if (e.sourceType === 'LIVE_EXTERNAL' && e.verificationState) { /* keep */ }
      if (Mem && typeof Mem.remember === 'function') { try { Mem.remember('project', stripSecrets(JSON.stringify(e)), (e.sourceType || 'v10'), 0.5); } catch (err) {} }
      else if (Mem && typeof Mem.add === 'function') { try { Mem.add('project', stripSecrets(JSON.stringify(e)), (e.sourceType || 'v10'), 0.5); } catch (err2) {} }
      return { ok: true, scope: 'LOCAL' };
    }
  };

  // ================= REGISTER V10 ACTIONS (canonical) =================
  var R = g.ACTION_REGISTRY;
  function regAct(id, risk, desc, ex, ve) { if (R && !R[id]) R[id] = { id: id, description: desc, risk: risk, reversible: false, requiresPermission: (risk === 'HIGH' || risk === 'CRITICAL'), execute: ex, verify: ve }; }
  regAct('v10_research', 'LOW', 'Run research via provider (honest; BACKEND_REQUIRED unless connected)',
    function (p) { var cat = p && p.category; var q = (p && p.query) || ''; var r = ResearchProvider.query(cat || 'research', q); return { ok: true, result: r }; },
    function (p, res) { return !!res && !!res.status; });
  regAct('v10_execute', 'MEDIUM', 'Execute an external integration (BACKEND_REQUIRED unless connected)',
    function (p) { var out = ExecutionAdapter.execute((p && p.category) || 'unknown', (p && p.op) || {}); return { ok: true, result: out }; },
    function (p, res) { return !!res && !!res.status; });

  // capabilities + status panel
  var caps = {
    research_providers: { name: 'Research provider', category: 'research', description: 'Live research via provider (BACKEND_REQUIRED by default)', risk: 'LOW', availability: 'backend_required' },
    market_validation: { name: 'Market validation', category: 'business', description: 'Opportunity evidence tiers (heuristic/simulated)', risk: 'LOW', availability: 'available' },
    external_verification: { name: 'External verification', category: 'quality', description: 'INTERNAL vs EXTERNAL verification classes', risk: 'LOW', availability: 'available' },
    execution_adapters: { name: 'Execution adapters', category: 'integration', description: 'Real execution integration layer', risk: 'LOW', availability: 'backend_required' },
    money_orchestrator_v10: { name: 'Money orchestrator V10', category: 'business', description: 'Evidence-gated decision package', risk: 'LOW', availability: 'available' }
  };
  if (capReg && typeof capReg.register === 'function') { Object.keys(caps).forEach(function (c) { try { capReg.register(c, caps[c]); } catch (e) {} }); }

  // minimal status renderer (non-invasive; does not touch existing panels)
  function statusPanel() {
    var id = 'sjv10-status';
    var el = g.document && g.document.getElementById(id);
    if (!g.document) return;
    if (!el) { el = g.document.createElement('div'); el.id = id; el.style.cssText = 'font:11px monospace;padding:4px 8px;color:#888;border-top:1px solid #eee;background:#fafafa;'; g.document.body.appendChild(el); }
    el.textContent = 'V10 backend: BACKEND_REQUIRED · research: ' + ResearchProvider.status('research') + ' · execution: ' + ResearchProvider.status('execution') + ' · provenance: LOCAL · external verification: none';
  }
  if (g.document && g.document.body) { try { statusPanel(); } catch (e) {} }

  g.SV10 = {
    engine: 'SJ.execute()', version: '0.3.0-v10', Provenance: Provenance, ResearchProvider: ResearchProvider, MarketValidation: MarketValidation, ExecutionAdapter: ExecutionAdapter, ExternalVerifier: ExternalVerifier, Recovery: Recovery, ExperimentV10: ExperimentV10, MoneyOrchestratorV10: MoneyOrchestratorV10, Persistence: PersistenceV10, statusPanel: statusPanel
  };
})();